import React, { Component } from 'react'
import logo from '../assets/img/logo.png'
import { Link, Redirect } from 'react-router-dom'
import axios from "axios";
// import Button from '@restart/ui/esm/Button'
import { APIURL } from '../components/constants/common';
import { Spinner ,    Button } from 'reactstrap';
import Select from 'react-select';


const options = [
    { value: 'a', label: 'a' },
    { value: 'b', label: 'b' },
];


export default class SignUp extends Component {
    constructor(props) {
        super(props);
        this.state = {
            signupData: {
                name: "",
                first_name: "",
                last_name: "",
                email: "",
                phone: "",
                language: "",
                introduction: "",
                license_number: "",
                password: "",
                c_password: "",
                address: "",
                city: "",
                street_name: "",
                street_number: "",
                zip_code: ""
            },
            languages: [],
            countrycode: "",
            countryId: "",
            countries: [0],
            States: [],
            stateId: "",
            user_type_id: 0,
            user_Type: "",
            selectType: "",
            msg: "",
            errMsg: {},
            scsMsg: "",
            user_types: [],
            redirect: false,
            isLoading: false,
            fullscrLoader: true,
            showPassword: false,
            Cofirm_showPassword: false,

        }
    }


    onChangehandler = (e, key) => {
        const { signupData } = this.state;
        signupData[e.target.name] = e.target.value;
        this.setState({ signupData, errMsg: "" });
        console.log(signupData)
    };

    handleUserType = (e) => {
        this.setState({
            user_type_id: e
        })
    }

    //get language
    getLanguages() {
        axios
            .get(APIURL + "languages")
            .then((response) => {
                let languages = response.data.languages;
                for (var c = 0; c < languages.length; c++) {
                    this.state.languages.push({ value: languages[c].id, label: languages[c].name })
                }


                console.log(this.state.languages)
            })
    }


    handleLanguages = (selectedLanguages) => {
        this.setState({ selectedLanguages });
    }

    getCountries() {
        axios
            .get(APIURL + "countries")
            .then((response) => {
                this.setState({
                    countries: response.data.countries
                })
            })
    }

    handleCountry(e) {
        this.setState({
            countryId: e
        }, () => {
            this.handleCountryState()
        })
        console.log(this.state.countryId)
    }

    handleCountryState = () => {
        console.log(this.state.countryId)
        axios
            .post(APIURL + "states", {
                country_id: this.state.countryId,
            })
            .then((response) => {
                console.log(response.data.states)
                this.setState({
                    States: response.data.states
                });
            })
            .catch((error) => {
                this.setState({
                    // isLoading: false,
                    // errMsg: error.response.data.error,
                })
                setTimeout(() => this.setState({ errMsg: "" }), 3000);
            });
    };


    handleState(e) {
        this.setState({
            stateId: e
        }, () => {
            this.handleCountryState()
        })
        console.log("stateId", this.state.stateId)
    }

    onSubmitHandler = (e) => {
        // console.log(JSON.stringify(this.state.selectedOptions))
        e.preventDefault()
        const { signupData } = this.state;
        const user_type = parseInt(this.state.user_type_id) === 0 ? "buyer" : parseInt(this.state.user_type_id) === 1 ? "agent" : "seller"
        signupData['user_type'] = user_type
        signupData['state'] = this.state.stateId
        signupData['country'] = this.state.countryId
        signupData['language'] = JSON.stringify(this.state.selectedLanguages)
        const success = this.props.location;
        this.setState({ isLoading: true });
        axios
            .post(APIURL + "register", this.state.signupData)
            .then((response) => {
                // console.log("register", response.data.accountVerified)
                this.setState({
                    scsMsg: response.data.message,
                    isLoading: false

                })
                localStorage.setItem("accountVerified", response.data.accountVerified);
                setTimeout(() => this.setState({
                    redirect: true
                }), 3000);
            })
            .catch(error => {
                this.setState({
                    isLoading: false,
                    redirect: false,
                    errMsg: error.response.data.error,
                })
               }
            );
    };
    showPassword() {
        this.setState({
            showPassword: !this.state.showPassword
        })
    }
    Cofirm_showPassword() {
        this.setState({
            Cofirm_showPassword: !this.state.Cofirm_showPassword
        })
    }

    
    componentDidMount() {

        setTimeout(() => this.setState({ fullscrLoader: "" }), 500);
        this.getCountries();
        this.getLanguages();
        this.handleCountry(231);
      
    }

    render() {
        console.log(this.props)
        if (this.state.redirect) {
            return <Redirect to="/signin" push={true} />;
        }
        return (
            <div className="resido-front">
                {this.state.fullscrLoader ? <div className="loader"> <Spinner type="grow" color="dark" style={{ width: '3rem', height: '3rem' }} /> </div> : ""}

                <div id="main-wrapper">

                    <div className="header header-light head-shadow">
                        <div className="container">
                            <nav id="navigation" className="navigation navigation-landscape">
                                <div className="nav-header">
                                    <Link className="nav-brand" to="/">
                                        <img src={logo} className="logo" alt="" />
                                    </Link>
                                    <div className="nav-toggle"></div>
                                </div>
                                <div className="nav-menus-wrapper" style={{ transitionProperty: "none" }}>
                                    <ul className="nav-menu">
                                        <li className=""><Link to="/">Home<span className="submenu-indicator"></span></Link></li>
                                        <li><Link to="/Listing">Listings<span className="submenu-indicator"></span></Link></li>
                                        <li><Link to="/features">Features<span className="submenu-indicator"></span></Link></li>
                                    </ul>
                                    <ul className="nav-menu nav-menu-social align-to-right">
                                        <li>
                                            <Link to="/signin" className="text-success">
                                                <i className="fas fa-user-circle mr-2"></i>Sign In</Link>
                                        </li>
                                     
                                    </ul>
                                </div>
                            </nav>
                        </div>
                    </div>

                    <div className="modal-dialog modal-dialog-centered signupForm " role="document" >
                        <div className="modal-content" id="registermodal">
                            <div class="card login-pop-form">
                                <div class="card-body">
                                    <h4 className="modal-header-title" style={{ margin: "0px" }}>Sign Up</h4>
                                    {this.state.scsMsg ? <div class="alert alert-success" role="alert">
                                        {this.state.scsMsg}
                                    </div> : ""}
                                    <div className="row mt-3 mb-3">
                                        <div className="col-lg-12 col-md-12">
                                            <div className="mb-3 d-flex justify-content-around ">
                                                <div className="input-with-icon">
                                                    <select className="form-control" id="dropdown" onChange={(e) => this.handleUserType(e.target.value)} >
                                                        <option value="0"  >As a Buyer</option>
                                                        <option value="1"  >As a Agent</option>
                                                        <option value="2"  >As a Seller</option>
                                                    </select>
                                                    <span className="text-danger">{this.state.errMsg.user_type}</span>
                                                    <i className="ti-briefcase"></i>
                                                </div>
                                                <span className="text-danger">{this.state.errMsg.user_type}</span>


                                                {/* <div class="form-check form-check-inline d-flex ">
                                                    <input class="form-check-input" type="radio" name="inlineRadioOptions" id="inlineRadio1" onChange={(e) => this.handleUserType(0)} checked={this.state.user_type_id === 0} />Buyer

                                                </div>
                                                <div class="form-check form-check-inline d-flex">
                                                    <input class="form-check-input" type="radio" name="inlineRadioOptions" id="inlineRadio2" onChange={(e) => this.handleUserType(1)} />Agent
                                                </div>
                                                <div class="form-check form-check-inline d-flex">
                                                    <input class="form-check-input" type="radio" name="inlineRadioOptions" id="inlineRadio3" onChange={(e) => this.handleUserType(2)} />Seller
                                                </div> */}
                                            </div>
                                        </div>
                                    </div>

                                    <div className="login-form">
                                        <form onSubmit={(e) => this.onSubmitHandler(e)}>
                                            <div className="row">
                                                <div className="col-lg-6 col-md-6">
                                                    <div className="form-group">
                                                        <label>First Name <strong className="text-danger" >*</strong></label>
                                                        <div className="input-with-icon">
                                                            <input
                                                                autoFocus={true}
                                                                className="form-control"
                                                                required=""
                                                                type="text"
                                                                name="name"
                                                                placeholder="First Name"
                                                                value={this.state.signupData.name}
                                                                onChange={this.onChangehandler}
                                                            />
                                                            <i className="ti-user"></i>
                                                        </div>
                                                        <span className="text-danger">{this.state.errMsg.name}</span>
                                                    </div>
                                                </div>
                                                <div className="col-lg-6 col-md-6">
                                                    <div className="form-group">
                                                        <label>Surname <strong className="text-danger" >*</strong></label>
                                                        <div className="input-with-icon">
                                                            <input

                                                                className="form-control"
                                                                required=""
                                                                type="text"
                                                                name="last_name"
                                                                placeholder="Surname"
                                                                value={this.state.signupData.last_name}
                                                                onChange={this.onChangehandler}
                                                            />
                                                            <i className="ti-user"></i>
                                                        </div>
                                                        <span className="text-danger">{this.state.errMsg.last_name}</span>
                                                    </div>
                                                </div>
                                                 <div className="col-lg-6 col-md-6">
                                                    <div className="form-group">
                                                        <label>Email Address<strong className="text-danger" >*</strong></label>
                                                        <div className="input-with-icon">
                                                            <input
                                                                className="form-control"
                                                                required=""
                                                                type="email"
                                                                name="email"
                                                                placeholder="Email Address"
                                                                value={this.state.signupData.email}
                                                                onChange={this.onChangehandler}
                                                            />
                                                            <i className="ti-email"></i>
                                                        </div>
                                                        <span className="text-danger">{this.state.errMsg.email}</span>
                                                    </div>
                                                </div>
                                            
                                                
                                                <div className="col-lg-6 col-md-6">
                                                    <div className="form-group">
                                                        <label>Country <strong className="text-danger" ></strong></label>
                                                        <div className="input-with-icon">
                                                            <select className="form-control" id="dropdown" onChange={(e) => this.handleCountry(e.target.value)}  >
                                                                <option  >Select Country</option>
                                                                {this.state.countries.length > 0 ?
                                                                    this.state.countries.map((item, idx) => (
                                                                        <option value={item.id} selected={item.id === 231}  >{item.name}</option>
                                                                    )) :
                                                                    <span></span>
                                                                }
                                                            </select>
                                                            <i class="fas fa-globe-asia"></i>
                                                        </div>
                                                        <span className="text-danger">{this.state.errMsg.country}</span>
                                                    </div>
                                                </div>

                                                <div className="col-lg-6 col-md-6">
                                                    <div className="form-group">
                                                        <label>State </label>
                                                        <div className="input-with-icon">
                                                            <select className="form-control" id="dropdown" onChange={(e) => this.handleState(e.target.value)}  >
                                                                <option >Select State</option>
                                                                {this.state.States.length > 0 ?
                                                                    this.state.States.map((item, idx) => (
                                                                        <option value={item.id} >{item.name}</option>
                                                                    )) :
                                                                    <span></span>
                                                                }
                                                            </select>
                                                            <i class="fas fa-city"></i>
                                                        </div>
                                                        <span className="text-danger">{this.state.errMsg.state}</span>
                                                    </div>
                                                </div>
                                                <div className="col-lg-6 col-md-6">
                                                    <div className="form-group">

                                                        <label> City </label>
                                                        <div className="input-with-icon">
                                                            <input
                                                                className="form-control"
                                                                required=""
                                                                name="city"
                                                                onkeypress="return isNumberKey(event)"
                                                                placeholder="City"
                                                                value={this.state.signupData.city}
                                                                onChange={this.onChangehandler}
                                                            />

                                                            <i class="fas fa-city"></i>
                                                        </div>
                                                        <span className="text-danger">{this.state.errMsg.city}</span>
                                                    </div>
                                                </div>
                                                <div className="col-lg-6 col-md-6">
                                                    <div className="form-group">
                                                        <label>Street Number</label>
                                                        <div className="input-with-icon">
                                                            <input
                                                                className="form-control"
                                                                required=""
                                                                type="number"
                                                                name="street_number"
                                                                placeholder="Street Number"
                                                                value={this.state.signupData.street_number}
                                                                onChange={this.onChangehandler}
                                                            />
                                                            <i class="fas fa-road"></i>
                                                        </div>
                                                        <span className="text-danger">{this.state.errMsg.street_number}</span>
                                                    </div>
                                                </div>
                                                <div className="col-lg-6 col-md-6">
                                                    <div className="form-group">
                                                        <label>Street Name</label>
                                                        <div className="input-with-icon">
                                                            <input
                                                                className="form-control"
                                                                required=""
                                                                type="text"
                                                                name="street_name"
                                                                placeholder="Street Name"
                                                                value={this.state.signupData.street_name}
                                                                onChange={this.onChangehandler}
                                                            />
                                                            <i class="fas fa-road"></i>
                                                        </div>
                                                        <span className="text-danger">{this.state.errMsg.street_name}</span>
                                                    </div>
                                                </div>
                                                
                                                <div className="col-lg-6 col-md-6">
                                                    <div className="form-group">

                                                        <label> Zip </label>
                                                        <div className="input-with-icon">
                                                            <input
                                                                className="form-control"
                                                                required=""
                                                                type="number"
                                                                min="0"
                                                                name="zip_code"
                                                                onkeypress="return isNumberKey(event)"
                                                                placeholder="Zip"
                                                                value={this.state.signupData.zip_code}
                                                                onChange={this.onChangehandler}
                                                            />

                                                            <i class="fas fa-mail-bulk"></i>
                                                        </div>
                                                        <span className="text-danger">{this.state.errMsg.zip_code}</span>
                                                    </div>
                                                </div>

                                                {/* <div className="col-lg-3 col-md-3">
                                                    <div className="form-group">
                                                        <div className="input-with-icon">
                                                            <input
                                                                className="form-control"
                                                                required=""
                                                                type="number"
                                                                name="phone"
                                                                // placeholder="Mobile"
                                                                value={this.state.countrycode}
                                                                onChange={this.onChangehandler}
                                                            />
                                                            <i className="lni-phone-handset"></i>
                                                        </div>
                                                    </div>
                                                </div> */}

<div className="col-lg-6 col-md-6">
                                                    <div className="form-group">

                                                        <label> Contact <strong className="text-danger" >*</strong></label>
                                                        <div className="input-with-icon">
                                                            <input
                                                                className="form-control"
                                                                required=""
                                                                type="number"
                                                                min="0"
                                                                name="phone"
                                                                onkeypress="return isNumberKey(event)"
                                                                placeholder="Contact"
                                                                value={this.state.signupData.phone}
                                                                onChange={this.onChangehandler}
                                                            />

                                                            <i className="lni-phone-handset"></i>
                                                        </div>
                                                        <span className="text-danger">{this.state.errMsg.phone}</span>
                                                    </div>
                                                </div>

                                                <div className="col-lg-12 col-md-12">
                                                    <div className="form-group">
                                                        <label> Language <strong className="text-danger" ></strong></label>

                                                        <div className="input-with-icon">

                                                            <Select
                                                                isMulti
                                                                placeholder="Select Language"
                                                                value={this.state.selectedLanguages}
                                                                onChange={this.handleLanguages}
                                                                options={this.state.languages}
                                                            />

                                                            {/* <select className="form-control" onChange={(e) => this.handleLanguages(e.target.value)} >
                                                                <option selected >Select Language</option>
                                                                {this.state.languages.map((option) => (
                                                                    <option value={option.id}>{option.name}</option>
                                                                ))}
                                                            </select> */}
                                                            {/* <i class="fas fa-language"></i> */}
                                                        </div>
                                                        <span className="text-danger">{this.state.errMsg.language}</span>
                                                    </div>
                                                </div>

                                                {/* <div className="col-lg-12 col-md-6">
                                                    <div className="form-group">
                                                        <label> Address <strong className="text-danger" ></strong></label>
                                                        <div className="input-with-icon">
                                                            <input
                                                                className="form-control"
                                                                required=""
                                                                type="textarea"
                                                                name="address"
                                                                placeholder="Address"
                                                                value={this.state.signupData.address}
                                                                onChange={this.onChangehandler}
                                                            />
                                                            <i class="fas fa-address-card"></i>
                                                        </div>
                                                        <span className="text-danger">{this.state.errMsg.address}</span>
                                                    </div>
                                                </div> */}
                                                {parseInt(this.state.user_type_id) === 1 ?
                                                    <div className="col-lg-12 col-md-6">
                                                        <div className="form-group">
                                                            <label> License Number <strong className="text-danger" ></strong></label>

                                                            <div className="input-with-icon">
                                                                <input
                                                                    className="form-control"
                                                                    required=""
                                                                    type="number"
                                                                    min="0"
                                                                    name="license_number"
                                                                    placeholder="License number"
                                                                    value={this.state.signupData.license_number}
                                                                    onChange={this.onChangehandler}
                                                                />
                                                                <i class="fas fa-address-card"></i>
                                                            </div>
                                                            <span className="text-danger">{this.state.errMsg.license_number}</span>
                                                        </div>
                                                    </div>
                                                    : ""}
                                                {
                                                    this.state.user_type_id === 1 ?
                                                        <div className="col-lg-12 col-md-6">
                                                            <div className="form-group">
                                                                <label> Introduction <strong className="text-danger" ></strong></label>

                                                                <div className="input-with-icon">
                                                                    <textarea
                                                                        className="form-control"
                                                                        required=""
                                                                        type="textarea"
                                                                        name="introduction"
                                                                        placeholder="Introduction"
                                                                        value={this.state.signupData.introduction}
                                                                        onChange={this.onChangehandler}
                                                                    >
                                                                    </textarea>
                                                                    <span className="text-danger">{this.state.errMsg.introduction}</span>

                                                                    <i class="fas fa-info info-sp"></i>
                                                                </div>
                                                                <span className="text-danger">{this.state.errMsg.introduction}</span>

                                                            </div>
                                                        </div>
                                                        : ""
                                                }
                                                <div className="col-lg-6 col-md-6">
                                                    <div className="form-group">
                                                        <label> Password <strong className="text-danger" >*</strong></label>

                                                        <div className="position-relative">
                                                            <div className="input-with-icon">
                                                                <input
                                                                    className="form-control"
                                                                    required=""
                                                                    type={this.state.showPassword ? "text" : "password"}
                                                                    name="password"
                                                                    placeholder="Password"
                                                                    value={this.state.signupData.password}
                                                                    onChange={this.onChangehandler}
                                                                />
                                                                <i className="ti-unlock"></i>
                                                            </div>
                                                            {this.state.showPassword ?
                                                                <span className="fa-eye-pass"> <i onClick={() => this.showPassword()} className="fas fa-eye-slash"></i> </span>
                                                                :
                                                                <span className="fa-eye-pass"> <i onClick={() => this.showPassword()} className="fas fa-eye"></i> </span>
                                                            }
                                                        </div>
                                                        <span className="text-danger">{this.state.errMsg.password}</span>

                                                    </div>
                                                </div>
                                                <div className="col-lg-6 col-md-6">
                                                    <div className="form-group">
                                                        <label> Confirm Password <strong className="text-danger" >*</strong></label>
                                                        <div className="position-relative">
                                                            <div className="input-with-icon">
                                                                <input
                                                                    className="form-control"
                                                                    required=""
                                                                    type={this.state.Cofirm_showPassword ? "text" : "password"}
                                                                    name="c_password"
                                                                    placeholder="Confirm Password"
                                                                    value={this.state.signupData.c_password}
                                                                    onChange={this.onChangehandler}
                                                                />
                                                                <i className="ti-unlock"></i>
                                                            </div>
                                                            {this.state.Cofirm_showPassword ?
                                                                <span className="fa-eye-pass"> <i onClick={() => this.Cofirm_showPassword()} className="fas fa-eye-slash"></i> </span>
                                                                :
                                                                <span className="fa-eye-pass"> <i onClick={() => this.Cofirm_showPassword()} className="fas fa-eye"></i> </span>
                                                            }
                                                        </div>
                                                        <span className="text-danger">{this.state.errMsg.c_password}</span>
                                                    </div>
                                                </div>
                                            </div>
                                            <div className="form-group">
                                                <Button
                                                    type="submit"
                                                    // onSubmit={() => this.onSubmitHandler()}
                                                    className="btn btn-md full-width btn-theme-light-2 rounded"
                                                >
                                                    Sign Up
                                                    {this.state.isLoading ? (
                                                        <span
                                                            className="spinner-border spinner-border-sm ml-2"
                                                            role="status"
                                                            aria-hidden="true"
                                                        ></span>
                                                    ) : (
                                                        <span></span>
                                                    )}
                                                </Button>
                                            </div>
                                        </form>
                                    </div>
                                    <div className="text-center">
                                        <p className="mt-3">
                                            <i className="ti-user mr-1"></i>
                                            Already Have An Account?
                                            <Link to="/signin" className="link">Go For LogIn</Link></p>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        )
    }
}
