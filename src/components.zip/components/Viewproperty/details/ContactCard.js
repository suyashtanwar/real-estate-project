import React, { Component } from 'react'

export default class ContactCard extends Component {
    render() {
        return (
            <div>
                <div className="sides-widget">
                    <div className="sides-widget-header">
                        <div className="agent-photo"><img src="https://via.placeholder.com/400x400" alt="" /></div>
                        <div className="sides-widget-details">
                            <h4><a href="#">Shivangi Preet</a></h4>
                            <span><i className="lni-phone-handset"></i>(91) 123 456 7895</span>
                        </div>
                        <div className="clearfix"></div>
                    </div>

                    <div className="sides-widget-body simple-form">
                        <div className="form-group">
                            <label>Email</label>
                            <input type="text" className="form-control" placeholder="Your Email" />
                        </div>
                        <div className="form-group">
                            <label>Phone No.</label>
                            <input type="text" className="form-control" placeholder="Your Phone" />
                        </div>
                        <div className="form-group">
                            <label>Description</label>
                            <textarea className="form-control">I'm interested in this property.</textarea>
                        </div>
                        <button className="btn btn-black btn-md rounded full-width">Send Message</button>
                    </div>
                </div>
            </div>
        )
    }
}
