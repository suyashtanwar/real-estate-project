import React, { Component } from 'react'
import Accordion from 'react-bootstrap/Accordion'
import Calculate from './Calculate'
import ContactCard from './ContactCard'
import FeaturedProperty from './FeaturedProperty'
import axios from 'axios';
import { APIURL } from '../../constants/common';
import SimpleImageSlider from "react-simple-image-slider"
import { Modal, ModalBody, ModalHeader, ModalFooter, Input, Spinner, Button, Card, CardBody, CardTitle, CardText } from 'reactstrap'
import { Carousel } from 'react-carousel-minimal';

// const data = [
//     {
//         image: "https://upload.wikimedia.org/wikipedia/commons/thumb/0/0c/GoldenGateBridge-001.jpg/1200px-GoldenGateBridge-001.jpg",
//         caption: `<div>
//                   San Francisco
//                   <br/>
//                   Next line
//                 </div>`
//     },
//     {
//         image: "https://cdn.britannica.com/s:800x450,c:crop/35/204435-138-2F2B745A/Time-lapse-hyper-lapse-Isle-Skye-Scotland.jpg",
//         caption: "Scotland"
//     },
//     {
//         image: "https://static2.tripoto.com/media/filter/tst/img/735873/TripDocument/1537686560_1537686557954.jpg",
//         caption: "Darjeeling"
//     },
//     {
//         image: "https://upload.wikimedia.org/wikipedia/commons/thumb/1/16/Palace_of_Fine_Arts_%2816794p%29.jpg/1200px-Palace_of_Fine_Arts_%2816794p%29.jpg",
//         caption: "San Francisco"
//     },
//     {
//         image: "https://i.natgeofe.com/n/f7732389-a045-402c-bf39-cb4eda39e786/scotland_travel_4x3.jpg",
//         caption: "Scotland"
//     },
//     {
//         image: "https://www.tusktravel.com/blog/wp-content/uploads/2020/07/Best-Time-to-Visit-Darjeeling-for-Honeymoon.jpg",
//         caption: "Darjeeling"
//     },
//     {
//         image: "https://www.omm.com/~/media/images/site/locations/san_francisco_780x520px.ashx",
//         caption: "San Francisco"
//     },
//     {
//         image: "https://images.ctfassets.net/bth3mlrehms2/6Ypj2Qd3m3jQk6ygmpsNAM/61d2f8cb9f939beed918971b9bc59bcd/Scotland.jpg?w=750&h=422&fl=progressive&q=50&fm=jpg",
//         caption: "Scotland"
//     },
//     {
//         image: "https://www.oyorooms.com/travel-guide/wp-content/uploads/2019/02/summer-7.jpg",
//         caption: "Darjeeling"
//     }
// ];

const captionStyle = {
    fontSize: '2em',
    fontWeight: 'bold',
  }
  const slideNumberStyle = {
    fontSize: '20px',
    fontWeight: 'bold',
  }
export default class Index extends Component {
    constructor() {
        super();

        this.state = {
            PropertyInfo: [],
            previewImages: false,
            ImagesList: [],
            Data: [
                {
                    image: "https://upload.wikimedia.org/wikipedia/commons/thumb/0/0c/GoldenGateBridge-001.jpg/1200px-GoldenGateBridge-001.jpg",
                    caption: `<div> San Francisco  <br/>   Next line   </div>`
                }
            ],
        }
    }

    previewImages() {
        this.setState({
            previewImages: !this.state.previewImages
        })
    }
    previewImagesClose() {
        this.setState({
            previewImages: false
        })
    }

    ViewpropertyDetails() {
        const formData = new FormData();
        formData.append('property_id', this.props.data.PropertyId);
        // this.setState({ Loader: true });
        axios
            .post(APIURL + "view-property-detail", formData, {

            })
            .then((response) => {
                this.setState({
                    PropertyInfo: response.data.data,
                })
                let Images = [];

                this.state.PropertyInfo.map((item, idx) => {
                    item.property_media.map((result, index) => {
                        Images.push({
                            image: result.url_path,
                            caption: `<div>
                            San Francisco
                            <br/>
                            Next line
                          </div>`
                        });
                        this.setState({
                            Data: Images
                        })
                    });
                })
                console.log("this.state ", this.state.Data)
            })
            .catch((error) => {

            });
    }

    componentDidMount() {
        this.ViewpropertyDetails()
    }
    render() {
        console.log("property View", this.props.data.PropertyId)
        return (
            <div>
                <section className="gray-simple">
                    <div className="container">
                        {this.state.PropertyInfo.length > 0 ?
                            this.state.PropertyInfo.map((item, idx) => (
                                <div className="row">
                                    <div className="col-lg-8 col-md-12 col-sm-12">

                                        <div className="property_block_wrap style-2 p-4">
                                            <div className="prt-detail-title-desc">
                                                <span className="prt-types sale">For Sale</span>
                                                <h3>{item.name}</h3>
                                                <span><i className="lni-map-marker"></i> {item.property_detail.apt_number} , {item.property_detail.street_name} , {item.property_detail.city} </span>
                                                <h3 className="prt-price-fix">${item.property_detail.listing_price}</h3>
                                                <div className="list-fx-features">
                                                    <div className="listing-card-info-icon">
                                                        <div className="inc-fleat-icon"><img src="assets/img/bed.svg" width="13" alt="" /></div>{item.property_detail.number_of_bedrooms} Beds
                                                    </div>
                                                    <div className="listing-card-info-icon">
                                                        <div className="inc-fleat-icon"><img src="assets/img/bathtub.svg" width="13" alt="" /></div>{item.property_detail.number_of_bathrooms} Bath
                                                    </div>
                                                    <div className="listing-card-info-icon">
                                                        <div className="inc-fleat-icon"><img src="assets/img/move.svg" width="13" alt="" /></div>{item.property_detail.lot_size}sqft
                                                    </div>
                                                </div>
                                            </div>
                                        </div>

                                        <Accordion defaultActiveKey="0" flush>
                                            <Accordion.Item eventKey="0">
                                                <Accordion.Header>Property Information</Accordion.Header>
                                                <Accordion.Body>
                                                    <ul className="deatil_features">
                                                        <li><strong>Number of Bedrooms:</strong>{item.property_detail.number_of_bedrooms === null ? "NA" : item.property_detail.number_of_bathroom} </li>
                                                        <li><strong>Number of Bathrooms:</strong>{item.property_detail.number_of_bathrooms === null ? "NA" : item.property_detail.number_of_bathrooms} </li>
                                                        <li><strong>Total Square Footage:</strong>{item.property_detail.total_square_footage === null ? "NA" : item.property_detail.total_square_footage}</li>
                                                        <li><strong>Lot Size:</strong>{item.property_detail.lot_size === null ? "NA" : item.property_detail.total_square_footage}</li>
                                                        <li><strong>House Description:</strong> {item.property_detail.house_description === null ? "NA" : item.property_detail.house_description}</li>
                                                        <li><strong>Flooring:</strong>{item.property_detail.flooring === "0" ? "HardWood" : item.property_detail.flooring === "1" ? "Carpet" : item.property_detail.flooring === "2" ? "Ceramic" : item.property_detail.flooring === "3" ? "Vinyl" : "Stone"}</li>
                                                        <li><strong>Fire Place:</strong>{item.property_detail.fireplace === 0 ? "No" : "Yes"}</li>
                                                        <li><strong>Swimming Pool:</strong>{item.property_detail.swimming_pool === 2 ? "No" : "Yes"}</li>
                                                        <li><strong>Year build:</strong>{item.property_detail.year_built === null ? "NA" : item.property_detail.year_built}</li>
                                                    </ul>
                                                </Accordion.Body>
                                            </Accordion.Item>
                                        </Accordion>
                                        {/* <Accordion defaultActiveKey="0" flush>
                                    <Accordion.Item eventKey="0">
                                        <Accordion.Header>Description</Accordion.Header>
                                        <Accordion.Body>
                                            <div className="block-body">
                                                <p>There are many variations of passages of Lorem Ipsum available, but the majority have suffered alteration in some form, by injected humour, or randomised words which don't look even slightly believable. If you are going to use a passage of Lorem Ipsum, you need to be sure there isn't anything embarrassing hidden in the middle of text. All the Lorem Ipsum generators on the Internet tend to repeat predefined chunks as necessary, making this the first true generator on the Internet.</p>
                                                <p>Sed ut perspiciatis unde omnis iste natus error sit voluptatem accusantium doloremque laudantium, totam rem aperiam, eaque ipsa quae ab illo inventore veritatis et quasi architecto beatae vitae dicta sunt explicabo.</p>
                                            </div>
                                        </Accordion.Body>
                                    </Accordion.Item>
                                </Accordion> */}
                                        <Accordion defaultActiveKey="0" flush>
                                            <Accordion.Item eventKey="0">
                                                <Accordion.Header>Address</Accordion.Header>
                                                <Accordion.Body>
                                                    <ul className="deatil_features">
                                                        <li><strong>Street Number:</strong>{item.property_detail.street_number === null ? "NA" : item.property_detail.street_number} </li>
                                                        <li><strong>Street Name:</strong>{item.property_detail.street_name === null ? "NA" : item.property_detail.street_name} </li>
                                                        <li><strong>Apartment Number:</strong>{item.property_detail.apt_number === null ? "NA" : item.property_detail.apt_number}</li>
                                                        <li><strong>Country:</strong>{item.property_detail.country_name ? item.property_detail.country_name : "NA"}</li>
                                                        <li><strong>State:</strong> {item.property_detail.state_name ? item.property_detail.state_name : "NA"}</li>
                                                        <li><strong>City:</strong>{item.property_detail.city === null ? "NA" : item.property_detail.city}</li>
                                                        <li><strong>Zip:</strong>{item.property_detail.zip === null ? "NA" : item.property_detail.zip}</li>
                                                        <li><strong>Map:</strong>NA</li>
                                                        {/* <li><strong>Year build:</strong>{sItem.year_built ? sItem.year_built : "NA" }</li> */}
                                                    </ul>

                                                </Accordion.Body>
                                            </Accordion.Item>
                                        </Accordion>
                                        <Accordion defaultActiveKey="1" flush>
                                            <Accordion.Item eventKey="0">
                                                <Accordion.Header>Features</Accordion.Header>
                                                <Accordion.Body>
                                                    <ul className="deatil_features">
                                                        <li><strong>Listing Price:</strong>{item.property_detail.listing_price ? item.property_detail.listing_price : "NA"} </li>
                                                        <li><strong>HOA Free:</strong>{item.property_detail.hoa_free ? item.property_detail.hoa_free : "NA"} </li>
                                                        <li><strong>Feature Type:</strong>{item.property_detail.feature_type ? item.property_detail.feature_type : "NA"}</li>
                                                        <li><strong>Bedrooms:</strong>{item.property_detail.total_bedrooms ? item.property_detail.total_bedrooms : "NA"} </li>
                                                        <li><strong>Bathrooms :</strong> {item.property_detail.total_bathrooms ? item.property_detail.total_bathrooms : "NA"} </li>
                                                        <li><strong>Full Bath:</strong>{item.property_detail.full_bath ? item.property_detail.full_bath : "NA"}</li>
                                                        <li><strong>Half Bath:</strong>{item.property_detail.half_bath ? item.property_detail.half_bath : "NA"}</li>
                                                        <li><strong>Cooling:</strong>{item.property_detail.cooling === "0" ? "No" : "Yes"}</li>
                                                        <li><strong>Heating :</strong> {item.property_detail.heating === "0" ? "Electic" : item.property_detail.heating === "1" ? "Natural Gas" : "Propane"}</li>
                                                        <li><strong>Parking Space:</strong>{item.property_detail.parking_space}</li>
                                                        <li><strong>Walkout:</strong>{item.property_detail.walkout === "0" ? "No" : "Yes"}</li>
                                                        <li><strong>Finished:</strong>{item.property_detail.finished === "0" ? "No" : "Yes"}</li>
                                                        <li><strong>Stories Of The House:</strong>{item.property_detail.stories_of_the_house ? item.property_detail.stories_of_the_house : "NA"}</li>
                                                    </ul>

                                                </Accordion.Body>
                                            </Accordion.Item>
                                        </Accordion>
                                        {/* <Accordion defaultActiveKey="1" flush>
                                    <Accordion.Item eventKey="0">
                                        <Accordion.Header>Property video</Accordion.Header>
                                        <Accordion.Body>
                                            <div className="block-body">
                                                <div className="property_video">
                                                    <div className="thumb">
                                                        <img className="pro_img img-fluid w100" src="https://via.placeholder.com/1200x800" alt="7.jpg" />
                                                        <div className="overlay_icon">
                                                            <div className="bb-video-box">
                                                                <div className="bb-video-box-inner">
                                                                    <div className="bb-video-box-innerup">
                                                                        <a href="https://www.youtube.com/watch?v=A8EI6JaFbv4" data-bs-toggle="modal" data-bs-target="#popup-video" className="theme-cl"><i className="ti-control-play"></i></a>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </Accordion.Body>
                                    </Accordion.Item>
                                </Accordion> */}

                                        {/* <Accordion defaultActiveKey="1" flush>
                                    <Accordion.Item eventKey="0">
                                        <Accordion.Header>Location</Accordion.Header>
                                        <Accordion.Body>
                                            <div className="block-body">
                                                <div className="map-container">
                                                    <div id="singleMap" data-latitude="40.7427837" data-longitude="-73.11445617675781" data-mapTitle="Our Location"></div>
                                                </div>

                                            </div>
                                        </Accordion.Body>
                                    </Accordion.Item>
                                </Accordion> */}
                                        <Accordion defaultActiveKey="1" flush>
                                            <Accordion.Item eventKey="0">
                                                <Accordion.Header>Gallery</Accordion.Header>
                                                <Accordion.Body>
                                                    <div className="form-group multi-preview">
                                                        <div className="card">
                                                            {this.state.scsMsg}
                                                            <div className="list-group list-group-flush">
                                                                <div className="row">
                                                                    {item.property_media &&
                                                                        item.property_media.map((file, index) => (
                                                                            <div className="col-sm-2">
                                                                                <div className="img-gallery">
                                                                                    <img className="w-100 " onClick={() => this.previewImages()} src={file.url_path} />
                                                                                </div> </div>
                                                                        ))}
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </Accordion.Body>
                                            </Accordion.Item>
                                        </Accordion>


                                    </div>

                                    <div className="col-lg-4 col-md-12 col-sm-12">

                                        <div className="like_share_wrap b-0">
                                            <ul className="like_share_list">
                                                <li><a href="JavaScript:Void(0);" className="btn btn-likes" data-toggle="tooltip" data-original-title="Share"><i className="fas fa-share"></i>Share</a></li>
                                                <li><a href="JavaScript:Void(0);" className="btn btn-likes" data-toggle="tooltip" data-original-title="Save"><i className="fas fa-heart"></i>Save</a></li>
                                            </ul>
                                        </div>

                                        <div className="details-sidebar">

                                            <ContactCard />

                                            <Calculate />

                                            <FeaturedProperty />

                                        </div>
                                    </div>
                                </div>
                            )) :
                            ""
                        }
                    </div>
                </section>
                <Modal size="xl" isOpen={this.state.previewImages} toggle={() => this.previewImagesClose()}>
                    <ModalHeader className="header-less ml-3" toggle={() => this.previewImagesClose()}>

                    </ModalHeader>
                    <ModalBody className="border-0">
                        <Carousel
                            data={this.state.Data}
                            time={1000}
                            width="850px"
                            height="400px"
                              captionStyle={captionStyle}
                            radius="10px"
                            slideNumber={true}
                              slideNumberStyle={slideNumberStyle}
                            captionPosition="bottom"
                            automatic={true}
                            dots={true}
                            pauseIconColor="white"
                            pauseIconSize="40px"
                            slideBackgroundColor="darkgrey"
                            slideImageFit="cover"
                            thumbnails={true}
                            thumbnailWidth="100px"
                            style={{
                                textAlign: "center",
                                maxWidth: "850px",
                                maxHeight: "500px",
                                margin: "40px auto",
                            }}
                        />
                    </ModalBody>
                    <ModalFooter>
                        <div className="d-flex justify-content-end w-100">
                            <Button className="btn btn-danger " onClick={() => this.previewImagesClose()}> <i className="fas fa-window-close mr-1"></i>Cancel </Button>
                        </div>
                    </ModalFooter>
                </Modal>
            </div>
        )
    }
}
