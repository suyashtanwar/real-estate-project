import React, { Component } from 'react'
import logo from '../../assets/img/logo.png'
import { Link } from 'react-router-dom'
import Map from "./Map/index"
import axios from 'axios';
import { APIURL } from '../constants/common';
import { Button } from 'reactstrap'
import bad from '../../assets/img/bed.svg'

export default class Index extends Component {
    constructor() {
        super();
        this.state = {
            user: JSON.parse(localStorage.getItem("userData")),
            user_type: localStorage.getItem("user_type"),
            navigate: false,
            PropertyList: [],
            search: "",
            hoaFree: "",
            featureTypeId: "",
            totalBathRooms: "",
            totalBedRooms: "",
            cooling: "",
            heating: "",
            flooring: "",
            fireplace: "",
            swimmingPool: "",
            minPrice: "",
            maxPrice: "",
            finished: "",
            Data: [
                {
                    "id": 123,
                    "title": "Think Company",
                    "website": "www.google.com",
                    "image":
                        "http://thinkcompany.fi/wp-content/uploads/2014/05/hkithinkco04-1024x702.jpg",
                    "address": [
                        {
                            "id": 1236,
                            "country": "Finland",
                            "city": "Helsinki",
                            "street": "Haartmansgatan 4",
                            "postcode": "00290",
                            "lat": "60.190711",
                            "lng": "24.907195"
                        }
                    ]
                },
            ]
        }
    }

    componentDidMount() {
        this.getPropertyList()


    }

    handleMinPrice = (e) => {
        console.log(e)
        this.setState({
            minPrice: e
        })
    }

    handleMaxPrice = (e) => {
        console.log(e)
        this.setState({
            maxPrice: e
        })
    }

    handleListingPrice = (e) => {
        this.setState({ listingPrice: !this.state.e })
    }
    handleHoa = (e) => {
        this.setState({
            hoaFree: e
        })
    }
    handleFlooring = () => {
        this.setState({
            flooring: !this.state.flooring
        })
    }

    handleFeatureType = (e) => {
        console.log(e)
        this.setState({
            featureTypeId: e
        })
    }
    handleTotalBedrooms = (e) => {
        this.setState({
            totalBedRooms: e
        })
    }

    handleTotalBathRooms = (e) => {
        this.setState({
            totalBathRooms: e
        })
    }
    handleFullBath = () => {
        this.setState({
            fullBath: !this.state.fullBath
        })
    }
    handleHalfBath = (e) => {
        this.setState({
            halfBath: !this.state.halfBath
        })
    }
    handleCooling = () => {
        this.setState({
            cooling: !this.state.cooling
        })
    }
    handleHeating = (e) => {
        this.setState({
            heating: e
        })
    }
    handleParkingSpace = () => {
        this.setState({
            parkingSpace: !this.state.parkingSpace
        })
    }

    handleWalkout = () => {
        this.setState({
            walkout: !this.state.walkout
        })
    }
    handleStoryHouse = () => {
        this.setState({
            storiesOfHouse: !this.state.storiesOfHouse
        })
    }
    handleFinished = () => {
        this.setState({
            finished: !this.state.finished
        })
    }

    handleFlooring = () => {
        this.setState({
            flooring: !this.state.flooring
        })
    }
    handleFirePlace = () => {
        this.setState({
            fireplace: !this.state.fireplace
        })
    }
    handlePool = () => {
        this.setState({
            swimmingPool: !this.state.swimmingPool
        })
    }

    handleSearch = (e) => {
        this.setState({
            search: e
        })
        console.log(this.state.search)
    }

    getPropertyList = () => {
        const formData = new FormData();
        formData.append('search', this.state.search);
        formData.append('min_price', this.state.minPrice);
        formData.append('max_price', this.state.maxPrice);
        formData.append('property_type', this.state.featureTypeId);
        formData.append('bathroom', this.state.totalBathRooms);
        formData.append('bedroom ', this.state.totalBedRooms);
        formData.append('cooling', this.state.cooling);
        formData.append('heating', this.state.heating);
        formData.append('fireplace', this.state.fireplace);
        formData.append('hoa_free', this.state.hoaFree);
        formData.append('parking_Space', this.state.parkingSpace);
        formData.append('swimming_Pool', this.state.swimmingPool);
        formData.append('finished', this.state.finished);

        this.setState({ Loader: true });
        axios
            .post(APIURL + "get-search-property", formData)
            .then((response) => {
                console.log("get-search-property", response.data.data.data)
                this.setState({
                    PropertyList: response.data.data.data,
                })
                let Address = [];
                this.state.PropertyList.map((item, idx) => {
                    item.property_detail.map((result, index) => {
                        console.log("result",result)
                        Address.push({
                              id: result.id,
                              country: result.country_name,
                              city: result.city,
                              street: result.state_name,
                              postcode: result.zip,
                              lat: result.lat,
                              lng: result.long
                        });
                        this.setState({
                            // Data:Address
                            Data: [
                                {
                                    "id": 123,
                                    "title": "Think Company",
                                    "website": "www.google.com",
                                    "image":
                                        "http://thinkcompany.fi/wp-content/uploads/2014/05/hkithinkco04-1024x702.jpg",
                                    address: [
                                        {
                                            id: 1236,
                                            country: result.country_name,
                                            city: result.city,
                                            street: result.state_name,
                                            postcode: result.zip,
                                            lat: result.lat,
                                            lng: result.long
                                        }
                                    ]
                                },
                            ]
                        })
                        console.log("data",this.state.Data)
                    });
                })
            })
            .catch((error) => {
                this.setState({
                    Loader: false
                })
            });
    };

    render() {
        // const { user } =  this.state
        return (
            <div className="resido-front">
                <div id="main-wrapper">

                    <div className="header header-light head-border">
                        <div className="container-fluid">
                            <nav id="navigation" className="navigation navigation-landscape">
                                <div className="nav-header">
                                    <a className="nav-brand" href="#">
                                        <img src={logo} className="logo" alt="" />
                                    </a>
                                    <div className="nav-toggle"></div>
                                </div>
                                <div className="nav-menus-wrapper" style={{ transitionProperty: "none" }}>
                                    <ul className="nav-menu">
                                        <li className=""><Link to="/">Home<span className="submenu-indicator"></span></Link></li>
                                        <li><Link to="/Listing">Listings<span className="submenu-indicator"></span></Link></li>
                                        <li><Link to="/features">Features<span className="submenu-indicator"></span></Link></li>
                                        <li>
                                            {this.state.user ?
                                                ""
                                                :
                                                <Link to="/signup" ><img src="assets/img/user.svg" width="12" alt="" className="mr-2" />Sign Up</Link>
                                            }
                                            {/* <Link href="JavaScript:Void(0);">SignUp<span className="submenu-indicator"></span></Link> */}
                                        </li>

                                    </ul>

                                    <ul className="nav-menu nav-menu-social align-to-right">
                                        <li>
                                            {this.state.user ?
                                                <Link to={this.state.user.user_type === "Agent" ? "/agent" : this.state.user.user_type === "Seller" ? "/seller" : "/Buyer"}  ><img src="assets/img/user.svg" width="12" alt="" className="mr-2" />Profile</Link>
                                                :
                                                <Link to="/signin" ><img src="assets/img/user.svg" width="12" alt="" className="mr-2" />Sign In</Link>
                                            }
                                            {/* <Link to="/signup" className="text-success">
                                                <i className="fas fa-user-circle mr-2"></i>Sign In</Link> */}
                                        </li>

                                    </ul>
                                </div>
                            </nav>
                        </div>
                    </div>
                    <div className="clearfix"></div>
                    <div className="home-map-banner half-map">

                        <div className="fs-left-map-box" style={{ height: "400px" }}>
                            <div className="home-map fl-wrap">
                                <div className="hm-map-container fw-map">
                                    {/* <div id="map"></div> */}
                                    <Map Data={this.state.Data} />
                                </div>
                            </div>
                        </div>

                        <div className="fs-inner-container">
                            <div className="fs-content">

                                <div className="row">
                                    <div className="col-lg-12 col-md-12">
                                        <div className="_mp_filter mb-3">
                                            <div className="_mp_filter_first">
                                                <h4>Where to Say?</h4>
                                                <div className="input-group">
                                                    <input type="text" className="form-control" value={this.state.search} onChange={(e) => this.handleSearch(e.target.value)} placeholder="Neighborhood, City etc." />
                                                    <div className="input-group-append">
                                                        <Button onClick={() => this.getPropertyList()} type="submit" className="input-group-text"><i className="fas fa-search"></i></Button>
                                                    </div>
                                                </div>
                                            </div>
                                            <div className="_mp_filter_last">
                                                <a className="map_filter" data-bs-toggle="collapse" href="#filtermap" role="button" aria-expanded="false" aria-controls="filtermap"><i className="fa fa-sliders-h mr-2"></i>Filter</a>
                                            </div>
                                        </div>
                                    </div>
                                    <div className="col-lg-12 col-md-12 mt-4">
                                        <div className="collapse" id="filtermap">
                                            <div className="row">
                                                <div class="form-group col-3">
                                                    <label for="exampleInputEmail3">Minimum price</label>
                                                    <select className="form-control" value={this.state.minPrice} onChange={(e) => this.handleMinPrice(e.target.value)} >
                                                        <option>Select</option>
                                                        <option value="500000">5 Lac</option>
                                                        <option value="1000000" >10 Lac</option>
                                                        <option value="200000">20 Lac</option>
                                                        <option value="3000000">30 Lac</option>
                                                        <option value="4000000">40 Lac</option>
                                                        <option value="5000000">50 Lac</option>
                                                        <option value="6000000">60 Lac</option>
                                                        <option value="7000000">70 Lac</option>
                                                        <option value="8000000">80 Lac</option>
                                                        <option value="9000000">90 Lac</option>
                                                        <option value="10000000"> 1 Cr</option>
                                                        <option value="12000000"> 1.2 Cr</option>
                                                        <option value="14000000"> 1.4 Cr</option>
                                                        <option value="16000000"> 1.6 Cr</option>
                                                        <option value="18000000"> 1.8 Cr</option>
                                                        <option value="20000000"> 2 Cr</option>
                                                        <option value="23000000"> 2.3 Cr</option>
                                                        <option value="26000000"> 2.6 Cr</option>
                                                        <option value="30000000"> 3 Cr</option>
                                                        <option value="35000000"> 3.5 Cr</option>
                                                        <option value="40000000"> 4 Cr</option>
                                                        <option value="45000000"> 4.5 Cr</option>
                                                        <option value="50000000"> 5 Cr</option>
                                                        <option value="100000000"> 10 Cr</option>
                                                        <option value="200000000"> 20 Cr</option>
                                                    </select>
                                                </div>
                                                <div class="form-group col-3">
                                                    <label for="exampleInputEmail3">Maximum price</label>
                                                    <select className="form-control" value={this.state.maxPrice} onChange={(e) => this.handleMaxPrice(e.target.value)} >
                                                        <option>Select</option>
                                                        <option value="500000">5 Lac</option>
                                                        <option value="1000000" >10 Lac</option>
                                                        <option value="200000">20 Lac</option>
                                                        <option value="3000000">30 Lac</option>
                                                        <option value="4000000">40 Lac</option>
                                                        <option value="5000000">50 Lac</option>
                                                        <option value="6000000">60 Lac</option>
                                                        <option value="7000000">70 Lac</option>
                                                        <option value="8000000">80 Lac</option>
                                                        <option value="9000000">90 Lac</option>
                                                        <option value="10000000"> 1 Cr</option>
                                                        <option value="12000000"> 1.2 Cr</option>
                                                        <option value="14000000"> 1.4 Cr</option>
                                                        <option value="16000000"> 1.6 Cr</option>
                                                        <option value="18000000"> 1.8 Cr</option>
                                                        <option value="20000000"> 2 Cr</option>
                                                        <option value="23000000"> 2.3 Cr</option>
                                                        <option value="26000000"> 2.6 Cr</option>
                                                        <option value="30000000"> 3 Cr</option>
                                                        <option value="35000000"> 3.5 Cr</option>
                                                        <option value="40000000"> 4 Cr</option>
                                                        <option value="45000000"> 4.5 Cr</option>
                                                        <option value="50000000"> 5 Cr</option>
                                                        <option value="100000000"> 10 Cr</option>
                                                        <option value="200000000"> 20 Cr</option>
                                                    </select>
                                                </div>
                                                <div class="form-group col-3">
                                                    <label for="exampleInputEmail3">Maximum price</label>
                                                    <select className="form-control" value={this.state.featureTypeId} onChange={(e) => this.handleFeatureType(e.target.value)} >
                                                        <option>Select</option>
                                                        <option value="0" >Condo</option>
                                                        <option value="1">Apartment</option>
                                                        <option value="2" >Single Family</option>
                                                        <option value="3">Townhouse</option>
                                                    </select>
                                                </div>
                                                <div class="form-group col-6">
                                                    <label for="exampleInputPassword4">Number of Bedrooms<strong className="text-danger" >*</strong></label>
                                                    <select className="form-control" value={this.state.totalBedRooms} onChange={(e) => this.handleTotalBedrooms(e.target.value)} >
                                                        <option >Select</option>
                                                        <option value="0">1</option>
                                                        <option value="1">2</option>
                                                        <option value="2">3</option>
                                                        <option value="3">4</option>
                                                        <option value="4">5</option>
                                                        <option value="5">6</option>
                                                        <option value="6">7</option>s
                                                        <option value="7">8</option>
                                                        <option value="8">9</option>
                                                    </select>
                                                    {/* <span className="text-danger">{this.state.errMsg.total_bedrooms}</span> */}
                                                </div>

                                                <div class="form-group col-6 ">
                                                    <label for="exampleInputName1">Number of Bathrooms <strong className="text-danger" >*</strong></label>
                                                    <select className="form-control" value={this.state.totalBathRooms} onChange={(e) => this.handleTotalBathRooms(e.target.value)} >
                                                        <option >Select</option>
                                                        <option value="0">1</option>
                                                        <option value="1">2</option>
                                                        <option value="2">3</option>
                                                        <option value="3">4</option>
                                                        <option value="4">5</option>
                                                        <option value="5">6</option>
                                                        <option value="6">7</option>
                                                        <option value="7">8</option>
                                                        <option value="8">9</option>
                                                    </select>
                                                    {/* <span className="text-danger">{this.state.errMsg.total_bathrooms}</span> */}
                                                </div>
                                                <div className="col-lg-12 col-md-12 col-sm-12">
                                                    <h6>Advance Features</h6>
                                                    <div className="row">
                                                        <div class="form-group col-6">
                                                            <label for="exampleInputEmail3">Heating</label>
                                                            <select className="form-control" value={this.state.heating} onChange={(e) => this.handleHeating(e.target.value)} >
                                                                <option>Select</option>
                                                                <option value="0" >Electric</option>
                                                                <option value="1">Nature Gas</option>
                                                                <option value="2" >Propane</option>
                                                            </select>
                                                        </div>
                                                        {/* <div class="form-group col-6">
                                                        <label for="exampleInputEmail3">Hoa Free</label>
                                                        <input type="text" className="form-control" value={this.state.hoaFree} onChange={(e) => this.handleHoa(e.target.value)} placeholder="Hoa Free" />
                                                    </div> */}
                                                    </div>
                                                    <ul className="row p-0 m-0">
                                                        <li className="col-xl-4 col-lg-6 col-md-6 p-0">
                                                            <input id="a-2" className="checkbox-custom" name="a-2" type="checkbox" value={this.state.cooling} onClick={this.handleCooling} />
                                                            <label for="a-2" className="checkbox-custom-label">Cooling</label>
                                                        </li>
                                                        {/* <li className="col-xl-4 col-lg-6 col-md-6 p-0">
                                                            <input id="a-3" className="checkbox-custom" name="a-3" type="checkbox"  value={this.state.heating} onClick={this.handleHeating} />
                                                            <label for="a-3" className="checkbox-custom-label">Heating</label>
                                                        </li> */}
                                                        <li className="col-xl-4 col-lg-6 col-md-6 p-0">
                                                            <input id="a-4" className="checkbox-custom" name="a-4" type="checkbox" value={this.state.parkingSpace} onClick={this.handleParkingSpace} />
                                                            <label for="a-4" className="checkbox-custom-label">Parking Space</label>
                                                        </li>
                                                        <li className="col-xl-4 col-lg-6 col-md-6 p-0">
                                                            <input id="a-5" className="checkbox-custom" name="a-5" type="checkbox" value={this.state.walkout} onClick={this.handleWalkout} />
                                                            <label for="a-5" className="checkbox-custom-label">Walkout</label>
                                                        </li>
                                                        <li className="col-xl-4 col-lg-6 col-md-6 p-0">
                                                            <input id="a-6" className="checkbox-custom" name="a-6" type="checkbox" value={this.state.fireplace} onClick={this.handleFirePlace} />
                                                            <label for="a-6" className="checkbox-custom-label">Fire Place</label>
                                                        </li>
                                                        <li className="col-xl-4 col-lg-6 col-md-6 p-0">
                                                            <input id="a-7" className="checkbox-custom" name="a-7" type="checkbox" value={this.state.swimmingPool} onClick={this.handlePool} />
                                                            <label for="a-7" className="checkbox-custom-label">Swimming Pool</label>
                                                        </li>
                                                        {/* <li className="col-xl-4 col-lg-6 col-md-6 p-0">
                                                            <input id="a-8" className="checkbox-custom" name="a-8" type="checkbox"  value={this.state.hoa_free} onClick={this.handleHoa}/>
                                                            <label for="a-8" className="checkbox-custom-label">HOA Free</label>
                                                        </li> */}
                                                        <li className="col-xl-4 col-lg-6 col-md-6 p-0">
                                                            <input id="a-9" className="checkbox-custom" name="a-9" type="checkbox" value={this.state.finished} onClick={this.handleFinished} />
                                                            <label for="a-9" className="checkbox-custom-label">Finished</label>
                                                        </li>
                                                    </ul>
                                                </div>

                                                <div className="col-lg-12 col-md-12 col-sm-12 mb-4 mt-4">
                                                    <div className="elgio_filter">
                                                        <div className="elgio_ft_first">
                                                            <button className="btn elgio_reset">
                                                                Reset<span className="reset_counter">0</span>
                                                            </button>
                                                        </div>
                                                        <div className="elgio_ft_last">
                                                            <button className="btn elgio_cancel mr-2">Cancel</button>
                                                            <button data-bs-toggle="collapse" href="#filtermap" role="button" aria-expanded="false" aria-controls="filtermap" onClick={this.getPropertyList} className="btn elgio_result mr-2">Save</button>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>

                                <div className="row list-layout">
                                    {this.state.PropertyList.length > 0 ? this.state.PropertyList.map((item, idx) => (
                                        <div className="col-lg-12 col-md-12">
                                            <div className="property-listing property-1">
                                                <div className="listing-img-wrapper">
                                                    <a href="single-property-2.html">
                                                        <img src="https://via.placeholder.com/1200x800" className="img-fluid mx-auto" alt="" />
                                                    </a>
                                                </div>

                                                <div className="listing-content">
                                                    <div className="listing-detail-wrapper-box">
                                                        <div className="listing-detail-wrapper">
                                                            <div className="listing-short-detail">
                                                                <h4 className="listing-name">
                                                                    <a href="single-property-2.html">{item.name}</a></h4>
                                                                <span className="prt-types sale">For Sale</span>
                                                            </div>
                                                            <div className="list-price">
                                                                <h6 className="listing-card-info-price">${item.property_detail.listing_price}</h6>
                                                            </div>
                                                        </div>
                                                    </div>

                                                    <div className="price-features-wrapper">
                                                        <div className="list-fx-features">
                                                            <div className="listing-card-info-icon">
                                                                <div className="inc-fleat-icon"><img src={bad} width="13" alt="" /></div>{item.property_detail.number_of_bedrooms} Beds
                                                            </div>
                                                            <div className="listing-card-info-icon">
                                                                <div className="inc-fleat-icon"><img src="assets/img/bathtub.svg" width="13" alt="" /></div>{item.property_detail.number_of_bathrooms} Bath
                                                            </div>
                                                            <div className="listing-card-info-icon">
                                                                <div className="inc-fleat-icon"><img src="assets/img/move.svg" width="13" alt="" /></div>{item.property_detail.lot_size} sqft
                                                            </div>
                                                        </div>
                                                    </div>

                                                    <div className="listing-footer-wrapper">
                                                        <div className="listing-locate">
                                                            <span className="listing-location"><i className="ti-location-pin"></i>{item.property_detail.city === "null" ? "NA" : item.property_detail.city}</span>
                                                        </div>
                                                        <div className="listing-detail-btn">
                                                            {/* <a href="single-property-2.html" className="more-btn">View</a> */}
                                                            <Link to={"/viewproperty/details/" + item.id} className="more-btn">View</Link>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    )) :
                                        <tr>
                                            <td colSpan="3" className="text-center">
                                                No Property Available
                                            </td>
                                        </tr>
                                    }
                                    <div className="row">
                                        <div className="col-lg-12 col-md-12 col-sm-12 text-center">
                                            <a href="listings-list-with-sidebar.html" className="btn btn-theme-light-2 rounded">Browse More Properties</a>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div className="clearfix"></div>
            </div>
        )
    }
}
