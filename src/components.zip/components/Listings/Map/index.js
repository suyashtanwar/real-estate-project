import React from "react";
import ReactDOM from "react-dom";
import SimpleMap from "./Map";
import { BrowserRouter, Link, Route } from "react-router-dom";
const locations = require("./locations.json");

function Map(props) {
  console.log("simple", props.Data)
  return (
    <div className="App">
      <SimpleMap
        locations={props.Data}
      />
    </div>
  );
}

export default Map
