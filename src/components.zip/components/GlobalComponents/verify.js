import React, { Component } from 'react'
import {Link } from 'react-router-dom'
import axios from "axios";
import { APIURL, BASEURL } from '../../components/constants/common';

export default class verify extends Component {
    constructor(){
        super();
        this.state = {
            scsMsg:""
        }
    }

    resendActivationMail = () => {
        const params = this.props.match.params;
        // api_url = "https://realstateapi.imenso.in/"
        axios
            .get(APIURL + "resend/email/"+74, {
                
            })
            .then((response) => {
                console.log(response)
                this.setState({
                    scsMsg:response.data.message,
                    errMsg:""
                })
            });
    }

    componentDidMount(){
        this.resendActivationMail()
    }
    render() {
        console.log(this.props)
        return (
            <div>
                Your Account is accountVerified
                <Link to="/">Login Your Account</Link>
            </div>
        )
    }
}
