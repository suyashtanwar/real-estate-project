import React, { Component } from 'react'
import { Link } from 'react-router-dom'

export default class ErrorPage extends Component {
    render() {
        return (
            <div id="notfound">
                <div class="notfound">
                    <div class="notfound-404">
                        <h1>403</h1>
                        <h2>Permission Denied</h2>
                    </div>
                    <Link to="/">Homepage</Link>
                </div>
            </div>
        )
    }
}
