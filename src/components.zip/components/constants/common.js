export const APIURL = "https://realstateapi.imenso.in/api/"
export const BASEURL = "https://realstateapi.imenso.in/api/"
export const APIDOMAIN = "https://realstateapi.imenso.in/api/"

// export const APIURL = "http://127.0.0.1:8000/api/"
// export const BASEURL = "http://127.0.0.1:8000/api/"
// export const APIDOMAIN = "http://127.0.0.1:8000/api/"


 