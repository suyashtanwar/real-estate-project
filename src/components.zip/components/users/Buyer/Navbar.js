import React, { Component } from 'react'
import { Link ,Redirect } from 'react-router-dom'
import logo from '../../../assets/img/logo.png'
import logoMini from '../../../assets/img/logo-mini.png'
import face1 from '../../../assets/images/faces/dummy.png'

export default class Navbar extends Component {
	constructor() {
        super();
        this.state = {
            user: JSON.parse(localStorage.getItem("userData")),
            user_type: localStorage.getItem("user_type"),
            navigate: false
        }
    }

    onLogoutHandler = () => {
        localStorage.removeItem("isLoggedIn");
        localStorage.removeItem("userData");
        localStorage.clear();
        this.setState({
            navigate: true,
        });
    };
    	
    render() {
        if (!this.state.user) {
            return <Redirect to="/" push={true} />;
        }

        if (this.state.navigate) {
            return <Redirect to="/" push={true} />;
        }
		const {user_type} = this.state
		return (
			<>
				<div class="header header-light head-shadow">
            <div class="container">
                <nav id="navigation" class="navigation navigation-landscape">
                <div class="text-center navbar-brand-wrapper d-flex align-items-center justify-content-center">
                        <Link class="navbar-brand brand-logo" to="/"><img src={logo} alt="logo" /></Link>
                        <Link class="navbar-brand brand-logo-mini" to="/"><img src={logoMini} alt="logo" /></Link>
                    </div>
                    <div class="nav-menus-wrapper" style={{transitionProperty:"none"}}>
                        <ul class="nav-menu">
                        
                            <li class="active"><Link href="#">Home<span class="submenu-indicator"></span></Link>
                               
                            </li>
                            
                            <li><Link to="/listing">Listings<span class="submenu-indicator"></span></Link>
                               
                            </li>
                            
                            <li><Link to="/features">Features<span class="submenu-indicator"></span></Link>
                                
                            </li>
                            
                            <li><a href="JavaScript:Void(0);">Pages<span class="submenu-indicator"></span></a>
                                
                            </li>
                            
                            {/* <li><a href="JavaScript:Void(0);" data-bs-toggle="modal" data-bs-target="#signup">Sign Up</a></li> */}
                            
                        </ul>
                        
                        <ul class="nav-menu nav-menu-social align-to-right">
                        <li><a href="" onClick={() => this.onLogoutHandler()} >
                            {/* <i class="ti-power-off"></i> */}
                            <strong>Logout</strong> <i data-bs-toggle="tooltip"   data-bs-placement="bottom" title="Logout" onClick={() => this.onLogoutHandler()} style={{fontSize:"18px"}} className="mdi mdi-power ml-1">  </i></a>
                            </li>    
                            {/* <li class="nav-item nav-logout d-none d-lg-block mr-3">
                                <a class="nav-link" href="#" onClick={() => this.onLogoutHandler()} style={{width:"50px"}}>
                                    <strong>Logout</strong>
                                
                                  </a>
                            </li>  */}
                       </ul>
                        
                    </div>
                </nav>
            </div>
        </div>
			</>
		)
	}
}
