import React, { Component } from 'react'

export default class Footer extends Component {
    render() {
        return (
            <>
                <section class="theme-bg call-to-act-wrap">
                        <div class="container">
                            <div class="row">
                                <div class="col-lg-12">

                                    <div class="call-to-act">
                                        <div class="call-to-act-head">
                                            <h3>Want to Become a Real Estate Agent?</h3>
                                            <span>We'll help you to grow your career and growth.</span>
                                        </div>
                                        <a href="#" class="btn btn-call-to-act">SignUp Today</a>
                                    </div>

                                </div>
                            </div>
                        </div>
                    </section>

                    <footer class="dark-footer skin-dark-footer">
                        <div>
                            <div class="container">
                                <div class="row">

                                    <div class="col-lg-3 col-md-3">
                                        <div class="footer-widget">
                                            <img src="assets/img/logo-light.png" class="img-footer" alt="" />
                                            <div class="footer-add">
                                                <p>Collins Street West, Victoria 8007, Australia.</p>
                                                <p>+1 246-345-0695</p>
                                                <p>info@example.com</p>
                                            </div>

                                        </div>
                                    </div>
                                    <div class="col-lg-2 col-md-2">
                                        <div class="footer-widget">
                                            <h4 class="widget-title">Navigations</h4>
                                            <ul class="footer-menu">
                                                <li><a href="#">About Us</a></li>
                                                <li><a href="#">FAQs Page</a></li>
                                                <li><a href="#">Checkout</a></li>
                                                <li><a href="#">Contact</a></li>
                                                <li><a href="#">Blog</a></li>
                                            </ul>
                                        </div>
                                    </div>

                                    <div class="col-lg-2 col-md-2">
                                        <div class="footer-widget">
                                            <h4 class="widget-title">The Highlights</h4>
                                            <ul class="footer-menu">
                                                <li><a href="#">Apartment</a></li>
                                                <li><a href="#">My Houses</a></li>
                                                <li><a href="#">Restaurant</a></li>
                                                <li><a href="#">Nightlife</a></li>
                                                <li><a href="#">Villas</a></li>
                                            </ul>
                                        </div>
                                    </div>

                                    <div class="col-lg-2 col-md-2">
                                        <div class="footer-widget">
                                            <h4 class="widget-title">My Account</h4>
                                            <ul class="footer-menu">
                                                <li><a href="#">My Profile</a></li>
                                                <li><a href="#">My account</a></li>
                                                <li><a href="#">My Property</a></li>
                                                <li><a href="#">Favorites</a></li>
                                                <li><a href="#">Cart</a></li>
                                            </ul>
                                        </div>
                                    </div>



                                </div>
                            </div>
                        </div>

                        <div class="footer-bottom">
                            <div class="container">
                                <div class="row align-items-center">

                                    <div class="col-lg-6 col-md-6">
                                        <p class="mb-0">© 2021 Resido. Designd By <a href="https://themezhub.com">Themez Hub</a> All Rights Reserved</p>
                                    </div>

                                    <div class="col-lg-6 col-md-6 text-right">
                                        <ul class="footer-bottom-social">
                                            <li><a href="#"><i class="ti-facebook"></i></a></li>
                                            <li><a href="#"><i class="ti-twitter"></i></a></li>
                                            <li><a href="#"><i class="ti-instagram"></i></a></li>
                                            <li><a href="#"><i class="ti-linkedin"></i></a></li>
                                        </ul>
                                    </div>

                                </div>
                            </div>
                        </div>
                    </footer>
            </>
        )
    }
}
