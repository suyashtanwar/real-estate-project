import React, { Component } from 'react'
import Navbar from './Navbar'
import Sidebar from './Sidebar'
import Footer from './Footer'
import Header from './Header'
import axios from "axios";
import { APIURL } from '../../../components/constants/common';
import { Redirect } from 'react-router'

export default class Index extends Component {
    constructor(props) {
        super(props);
        this.state = {
            token: JSON.parse(localStorage.getItem("token")),
            user: JSON.parse(localStorage.getItem("userData")),
            userInfo: {
                name: "",
                email: "",
                phone: "",
                state: "",
                language: "",
                stateId: "",
                image: ""
            },
            languages:[],
            countries: [],
            States: [],
            state: "",
            name: "",
            image: "",
            selectType: "",
            msg: "",
            errMsg: "",
            scsMsg: "",
        }
    }

    componentDidMount() {
        this.getProfileInfo()
        this.getCountries()
        this.getLanguages()
    }

    //form handler

    onChangehandler = (e, key) => {
        const { userInfo } = this.state;
        userInfo[e.target.name] = e.target.value;
        this.setState({ userInfo });
        console.log(userInfo)
    };


    //profile information
    getProfileInfo() {
        if (this.state.user) {
            const formData = new FormData();
            formData.append('id', this.state.user.id);
            var token = this.state.token
            var app_url = APIURL+"buyer/edit-profile"
            axios
                .post(app_url, formData, {
                    headers: {
                        'Authorization': `Bearer ${token}`
                    }
                })
                .then((response) => {
                    const info = response.data.data;
                    this.setState({
                        name: response.data.data.name,
                        userInfo: {
                            name: info.name,
                            email: info.email,
                            phone: info.phone,
                            address: info.address,
                        },
                        language:response.data.data.language,
                        country: response.data.data.country,
                        state: response.data.data.state
                    })
                    console.log("sssssssss", this.state.userInfo)
                })
                .catch((error) => {
                    this.setState({
                        // errMsg: error.response.data.errors,
                        Loader: false
                    })
                });
        }
    }

//    get languages

    getLanguages() {
        axios
            .get(APIURL + "languages")
            .then((response) => {
                this.setState({
                    languages: response.data.languages
                })
                console.log(this.state.languages)
            })
    }

    //get language
    handleLanguages(e){
        this.setState({
            language:e
        })
    }

    //get countries

    getCountries() {
        axios
            .get(APIURL + "countries")
            .then((response) => {
                this.setState({
                    countries: response.data.countries
                })
            })
    }

    // handle country
    handleCountry(e) {
        this.setState({
            country: e,
            state: ""
        }, () => {
            this.handleCountryState()
        })
    }

    // get states
    handleCountryState = () => {
        axios
            .post(APIURL + "states", {
                country_id: this.state.country,
            })
            .then((response) => {
                this.setState({
                    States: response.data.states,
                });
            })
            .catch((error) => {
                this.setState({

                })
            });
    };

    // handle states
    handleState(e) {
        this.setState({
            state: e
        })
    }

    //profile image change handler
    handleChangeLogo = (e) => {
        this.setState({
            image: e.target.files[0]
        })
        console.log(this.state.image)
    }

    //    update  profile submit handler

    onSubmitHandler = (e) => {
        var token = this.state.token
        const { userInfo ,user } = this.state;
        userInfo['state'] = this.state.state;
        userInfo['country'] = this.state.country;
        userInfo['profile_image'] = this.state.image;
        userInfo['languages'] = this.state.language;
        userInfo['id'] = user.id;
        userInfo['user_type'] = user.user_type;

        this.setState({ Loader: true });
        axios
            .post(APIURL + "seller/update-profile", this.state.userInfo, {
                headers: {
                    'Authorization': `Bearer ${token}`
                }
            })
            .then((response) => {
                this.setState({ Loader: false });
                this.setState({
                    errMsg: {},
                }, () => {
                    this.getProfileInfo();
                });
            })
            .catch((error) => {
                console.log(error.response.data)
                this.setState({
                    errMsg: error.response.data.error,
                    Loader: false
                })
            });
    };
    render() {
         if (!this.state.user) {
            return <Redirect to="/signin" />;
        }
        return (
            <>
                <div id="main-wrapper" class="resido-front">
                    <Navbar />
                    <div class="clearfix"></div>
                    <Header />
                    <section class="bg-light">
                        <div class="container-fluid">
                            <div class="row">
                                <div class="col-lg-3 col-md-12">
                                    <Sidebar />
                                </div>
                                <div class="col-lg-9 col-md-12">
							<div class="dashboard-wraper">
							
								{/* <!-- Bookmark Property --> */}
								<div class="form-submit">	
									<h4>My Property</h4>
								</div>
								
								<div class="row">
								
									{/* <!-- Single Property --> */}
									<div class="col-md-12 col-sm-12 col-md-12">
										<div class="singles-dashboard-list">
											<div class="sd-list-left">
												<img src="https://via.placeholder.com/1200x800" class="img-fluid" alt="" />
											</div>
											<div class="sd-list-right">
												<h4 class="listing_dashboard_title"><a href="#" class="theme-cl">My List property Name</a></h4>
												<div class="user_dashboard_listed">
													Price: from $ 154 month
												</div>
												<div class="user_dashboard_listed">
													Listed in <a href="javascript:void(0);" class="theme-cl">Rentals</a> and <a href="javascript:void(0);" class="theme-cl">Apartments</a>
												</div>
												<div class="user_dashboard_listed">
													City: <a href="javascript:void(0);" class="theme-cl">KASIA</a> , Area:540 sq ft
												</div>
												<div class="action">
													<a href="#" data-bs-toggle="tooltip" data-bs-placement="top" title="Edit"><i class="ti-pencil"></i></a>
													<a href="#" data-bs-toggle="tooltip" data-bs-placement="top" title="202 User View"><i class="ti-eye"></i></a>
													<a href="#" data-bs-toggle="tooltip" data-bs-placement="top" title="Delete Property" class="delete"><i class="ti-close"></i></a>
													<a href="#" data-bs-toggle="tooltip" data-bs-placement="top" title="Make Featured" class="delete"><i class="ti-star"></i></a>
												</div>
											</div>
										</div>
									</div>
									
									{/* <!-- Single Property --> */}
									<div class="col-md-12 col-sm-12 col-md-12">
										<div class="singles-dashboard-list">
											<div class="sd-list-left">
												<img src="https://via.placeholder.com/1200x800" class="img-fluid" alt="" />
											</div>
											<div class="sd-list-right">
												<h4 class="listing_dashboard_title"><a href="#" class="theme-cl">My List property Name</a></h4>
												<div class="user_dashboard_listed">
													Price: from $ 154 month
												</div>
												<div class="user_dashboard_listed">
													Listed in <a href="javascript:void(0);" class="theme-cl">Rentals</a> and <a href="javascript:void(0);" class="theme-cl">Apartments</a>
												</div>
												<div class="user_dashboard_listed">
													City: <a href="javascript:void(0);" class="theme-cl">KASIA</a> , Area:540 sq ft
												</div>
												<div class="action">
													<a href="#" data-bs-toggle="tooltip" data-bs-placement="top" title="Edit"><i class="ti-pencil"></i></a>
													<a href="#" data-bs-toggle="tooltip" data-bs-placement="top" title="202 User View"><i class="ti-eye"></i></a>
													<a href="#" data-bs-toggle="tooltip" data-bs-placement="top" title="Delete Property" class="delete"><i class="ti-close"></i></a>
													<a href="#" data-bs-toggle="tooltip" data-bs-placement="top" title="Make Featured" class="delete"><i class="ti-star"></i></a>
												</div>
											</div>
										</div>
									</div>
									
									{/* <!-- Single Property --> */}
									<div class="col-md-12 col-sm-12 col-md-12">
										<div class="singles-dashboard-list">
											<div class="sd-list-left">
												<img src="https://via.placeholder.com/1200x800" class="img-fluid" alt="" />
											</div>
											<div class="sd-list-right">
												<h4 class="listing_dashboard_title"><a href="#" class="theme-cl">My List property Name</a></h4>
												<div class="user_dashboard_listed">
													Price: from $ 154 month
												</div>
												<div class="user_dashboard_listed">
													Listed in <a href="javascript:void(0);" class="theme-cl">Rentals</a> and <a href="javascript:void(0);" class="theme-cl">Apartments</a>
												</div>
												<div class="user_dashboard_listed">
													City: <a href="javascript:void(0);" class="theme-cl">KASIA</a> , Area:540 sq ft
												</div>
												<div class="action">
													<a href="#" data-bs-toggle="tooltip" data-bs-placement="top" title="Edit"><i class="ti-pencil"></i></a>
													<a href="#" data-bs-toggle="tooltip" data-bs-placement="top" title="202 User View"><i class="ti-eye"></i></a>
													<a href="#" data-bs-toggle="tooltip" data-bs-placement="top" title="Delete Property" class="delete"><i class="ti-close"></i></a>
													<a href="#" data-bs-toggle="tooltip" data-bs-placement="top" title="Make Featured" class="delete"><i class="ti-star"></i></a>
												</div>
											</div>
										</div>
									</div>
									
									{/* <!-- Single Property --> */}
									<div class="col-md-12 col-sm-12 col-md-12">
										<div class="singles-dashboard-list">
											<div class="sd-list-left">
												<img src="https://via.placeholder.com/1200x800" class="img-fluid" alt="" />
											</div>
											<div class="sd-list-right">
												<h4 class="listing_dashboard_title"><a href="#" class="theme-cl">My List property Name</a></h4>
												<div class="user_dashboard_listed">
													Price: from $ 154 month
												</div>
												<div class="user_dashboard_listed">
													Listed in <a href="javascript:void(0);" class="theme-cl">Rentals</a> and <a href="javascript:void(0);" class="theme-cl">Apartments</a>
												</div>
												<div class="user_dashboard_listed">
													City: <a href="javascript:void(0);" class="theme-cl">KASIA</a> , Area:540 sq ft
												</div>
												<div class="action">
													<a href="#" data-bs-toggle="tooltip" data-bs-placement="top" title="Edit"><i class="ti-pencil"></i></a>
													<a href="#" data-bs-toggle="tooltip" data-bs-placement="top" title="202 User View"><i class="ti-eye"></i></a>
													<a href="#" data-bs-toggle="tooltip" data-bs-placement="top" title="Delete Property" class="delete"><i class="ti-close"></i></a>
													<a href="#" data-bs-toggle="tooltip" data-bs-placement="top" title="Make Featured" class="delete"><i class="ti-star"></i></a>
												</div>
											</div>
										</div>
									</div>
									
									{/* <!-- Single Property --> */}
									<div class="col-md-12 col-sm-12 col-md-12">
										<div class="singles-dashboard-list">
											<div class="sd-list-left">
												<img src="https://via.placeholder.com/1200x800" class="img-fluid" alt="" />
											</div>
											<div class="sd-list-right">
												<h4 class="listing_dashboard_title"><a href="#" class="theme-cl">My List property Name</a></h4>
												<div class="user_dashboard_listed">
													Price: from $ 154 month
												</div>
												<div class="user_dashboard_listed">
													Listed in <a href="javascript:void(0);" class="theme-cl">Rentals</a> and <a href="javascript:void(0);" class="theme-cl">Apartments</a>
												</div>
												<div class="user_dashboard_listed">
													City: <a href="javascript:void(0);" class="theme-cl">KASIA</a> , Area:540 sq ft
												</div>
												<div class="action">
													<a href="#" data-bs-toggle="tooltip" data-bs-placement="top" title="Edit"><i class="ti-pencil"></i></a>
													<a href="#" data-bs-toggle="tooltip" data-bs-placement="top" title="202 User View"><i class="ti-eye"></i></a>
													<a href="#" data-bs-toggle="tooltip" data-bs-placement="top" title="Delete Property" class="delete"><i class="ti-close"></i></a>
													<a href="#" data-bs-toggle="tooltip" data-bs-placement="top" title="Make Featured" class="delete"><i class="ti-star"></i></a>
												</div>
											</div>
										</div>
									</div>
									
								</div>
								
							</div>
						</div>
                            </div>
                        </div>
                    </section>
                    <Footer />
                </div>
            </>
        )
    }
}
