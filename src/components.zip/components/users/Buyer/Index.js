import React, { Component } from 'react'
import Navbar from './Navbar'
import logo from '../../../assets/img/logo.png'
import Sidebar from './Sidebar'
import Footer from './Footer'
import Header from './Header'
import { Redirect } from 'react-router'

export default class Index extends Component {
    constructor(){
        super();
        this.state = {
            user: JSON.parse(localStorage.getItem("userData")),
        }
    }
    render() {
        if (!this.state.user) {
            return <Redirect to="/signin" />;
        }
        if(this.state.user.user_type !== "Buyer"){
            return <Redirect to="/permission" />;
        }
        return (
            <>
                <div id="main-wrapper" class="resido-front">
                    <Navbar />
                    <div class="clearfix"></div>
                    <Header />
                    <section class="bg-light">
                        <div class="container-fluid">
                            <div class="row">
                                <div class="col-lg-3 col-md-12">
                                    <Sidebar />
                                </div>
                                <div class="col-lg-9 col-md-12">
                                    <div class="dashboard-wraper">

                                        <div class="form-submit">
                                            <h4>Coming Soon</h4>
                                            {/* <div class="submit-section">
                                                <div class="row">

                                                    <div class="form-group col-md-6">
                                                        <label>Your Name</label>
                                                        <input type="text" class="form-control" value="Shaurya Preet" />
                                                    </div>

                                                    <div class="form-group col-md-6">
                                                        <label>Email</label>
                                                        <input type="email" class="form-control" value="preet77@gmail.com" />
                                                    </div>

                                                    <div class="form-group col-md-6">
                                                        <label>Your Title</label>
                                                        <input type="text" class="form-control" value="Web Designer" />
                                                    </div>

                                                    <div class="form-group col-md-6">
                                                        <label>Phone</label>
                                                        <input type="text" class="form-control" value="123 456 5847" />
                                                    </div>

                                                    <div class="form-group col-md-6">
                                                        <label>Address</label>
                                                        <input type="text" class="form-control" value="522, Arizona, Canada" />
                                                    </div>

                                                    <div class="form-group col-md-6">
                                                        <label>City</label>
                                                        <input type="text" class="form-control" value="Montquebe" />
                                                    </div>

                                                    <div class="form-group col-md-6">
                                                        <label>State</label>
                                                        <input type="text" class="form-control" value="Canada" />
                                                    </div>

                                                    <div class="form-group col-md-6">
                                                        <label>Zip</label>
                                                        <input type="text" class="form-control" value="160052" />
                                                    </div>

                                                    <div class="form-group col-md-12">
                                                        <label>About</label>
                                                        <textarea class="form-control">Maecenas quis consequat libero, a feugiat eros. Nunc ut lacinia tortor morbi ultricies laoreet ullamcorper phasellus semper</textarea>
                                                    </div>

                                                </div>
                                            </div> */}
                                        </div>
                                    </div>
                                </div>

                            </div>
                        </div>
                    </section>

                    <Footer />
                </div>
            </>
        )
    }
}
