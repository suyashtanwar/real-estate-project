import React, { Component } from 'react'
import { Link ,Redirect } from 'react-router-dom'
import axios from "axios";
// import face1 from '../../../assets/images/faces/dummy.png'
import { APIURL } from '../../../components/constants/common';


export default class Sidebar extends Component {
    constructor() {
        super();
        this.state = {
            token: JSON.parse(localStorage.getItem("token")),
            user: JSON.parse(localStorage.getItem("userData")),
            user_type: localStorage.getItem("user_type"),
            navigate: false,
            profile_image:""
        }
    }

    onLogoutHandler = () => {
        localStorage.removeItem("isLoggedIn");
        localStorage.removeItem("userData");
        localStorage.clear();
        this.setState({
            navigate: true,
        });
    };

    getProfileInfo() {
        if (this.state.user) {
            const formData = new FormData();
            // formData.append('token', this.state.token);
            formData.append('id', this.state.user.id);
            var token = this.state.token
            var app_url = APIURL+"agent/edit-profile"
            axios
                .post(app_url, formData, {
                    headers: {
                        'Authorization': `Bearer ${token}`
                    }
                })
                .then((response) => {
                    
                    const info = response.data.data;
                    this.setState({
                        profile_image: response.data.data.url_path,
                        name:response.data.data.name
                    })
                    console.log("bjsbvjx",this.state.profile_image)
                })
                .catch((error) => {
                    this.setState({
                        // errMsg: error.response.data.errors,
                        Loader: false
                    })
                });
        }
    }

    componentDidMount(){
        this.getProfileInfo()
    }

    render() {
        const {user ,name} = this.state
         if(this.state.user.user_type !== "Buyer"){
        return <Redirect to="/permission" />;
    }
        if (!this.state.user) {
            return <Redirect to="/" push={true} />;
        }

        if (this.state.navigate) {
            return <Redirect to="/" push={true} />;
        }
        return (
            <div>
                 <div class="simple-sidebar sm-sidebar" id="filter_search">
                                        <div class="sidebar-widgets">
                                            <div class="dashboard-navbar">

                                                <div class="d-user-avater">
                                                <img src={this.state.profile_image ? this.state.profile_image : "face1"} alt="profile" />
                                                    <h4>{name}</h4>
                                                </div>
                                                <div class="d-navigation">
                                                    <ul>
                                                        <li><Link to="/buyer"><i class="ti-dashboard"></i>Dashboard</Link></li>
                                                        <li><Link to="/buyer/Profile"><i class="ti-user"></i>My Profile</Link></li>
                                                        {/* <li><Link href="bookmark-list.html"><i class="ti-bookmark"></i>Bookmarked Listings</Link></li> */}
                                                        <li><Link to="/buyer/property"><i class="ti-layers"></i>Wishlist</Link></li>
                                                        {/* <li><a href="submit-property-dashboard.html"><i class="ti-pencil-alt"></i>Submit New Property</a></li> */}
                                                        <li><Link to="/buyer/changepassword"><i class="ti-unlock"></i>Change Password</Link></li>
                                                        <li><a href="" onClick={() => this.onLogoutHandler()}><i class="ti-power-off"></i>Log Out</a></li>
                                                    </ul>
                                                </div>

                                            </div>
                                        </div>

                                    </div>
            </div>
        )
    }
}
