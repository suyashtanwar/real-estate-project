import React, { Component } from 'react'
import Navbar from './Navbar'
import Sidebar from './Sidebar'
import Footer from './Footer'
import Header from './Header'
import axios from "axios";
import { APIURL } from '../../../components/constants/common';
import { Button ,Spinner } from 'reactstrap'
import { Redirect } from 'react-router'

export default class Index extends Component {
    constructor() {
        super();
        this.state = {
            token: JSON.parse(localStorage.getItem("token")),
            user: JSON.parse(localStorage.getItem("userData")),
            user_type: localStorage.getItem("user_type"),
            navigate: false,
            userInfo: {
                current_password: "",
                password: "",
                confirm_password: "",
            },
            errMsg: "",
            scsMsg: "",
            currShowPassword: false,
            newShowPassword: false,
            confirmShowPassword: false,
        }
    }

    componentDidMount() {
        console.log(this.state.user_type)
    }

    currShowPassword() {
        this.setState({
            currShowPassword: !this.state.currShowPassword
        })
    }
    newShowPassword() {
        this.setState({
            newShowPassword: !this.state.newShowPassword
        })
    }
    confirmShowPassword() {
        this.setState({
            confirmShowPassword: !this.state.confirmShowPassword
        })
    }

    //form handler
    onChangehandler = (e, key) => {
        const { userInfo } = this.state;
        userInfo[e.target.name] = e.target.value;
        this.setState({ userInfo });
        console.log(userInfo)
    };


    onLogoutHandler = () => {

        localStorage.removeItem("isLoggedIn");
        localStorage.removeItem("userData");
        localStorage.clear();
        this.setState({
            navigate: true,
        });
    };

    onSubmitHandler = (e) => {
        var token = this.state.token
        const { userInfo, user } = this.state;
        userInfo['email'] = user.email;
        this.setState({ Loader: true });
        axios
            .post(APIURL + "change-password/update", this.state.userInfo, {
                headers: {
                    'Authorization': `Bearer ${token}`
                }
            })
            .then((response) => {
                this.setState({ Loader: false  })
                this.setState({
                    scsMsg: response.data.message,
                })
                setTimeout(()=>{
                    window.location.reload();
                }, 3000);
            })
            .catch((error) => {
                this.setState({
                    errMsg: error.response.data.error,
                    Loader: false
                })
                setTimeout(()=>{
                    window.location.reload();
                }, 3000);
            });
    };
    render() {
         if (!this.state.user) {
            return <Redirect to="/signin" />;
        }
        return (
            <>
             {this.state.Loader ? <div className="loader"> <Spinner type="grow" color="dark" style={{ width: '3rem', height: '3rem' }} /> </div> : ""}

                <div id="main-wrapper" class="resido-front">
                    <Navbar />
                    <div class="clearfix"></div>
                    <Header />
                    <section class="bg-light">
                        <div class="container-fluid">
                            <div class="row">
                                <div class="col-lg-3 col-md-12">
                                    <Sidebar />
                                </div>
                                <div class="col-lg-9 col-md-12">
                                    <div class="dashboard-wraper">

                                        <div class="form-submit">
                                            <h4>Change Password</h4>
                                            {this.state.scsMsg ? <div class="alert alert-success" role="alert"> {this.state.scsMsg} </div> : ""}
                                            {/* messgae err */}
                                            {this.state.errMsg.message ? <div class="alert alert-danger" role="alert">  {this.state.errMsg.message}   </div> : ""}
                                            <div class="submit-section mt-3">
                                                <div class="row">
                                                    <div className="col-lg-6 col-md-6" >
                                                        <div class="form-group col-lg-12 col-md-12">
                                                            <label>Current Password</label>
                                                            <div className="position-relative">
                                                                <input
                                                                    className="form-control"
                                                                    required=""
                                                                    type={this.state.currShowPassword ? "text" : "password"}
                                                                    name="current_password"
                                                                    placeholder="Current Password"
                                                                    value={this.state.current_password}
                                                                    onChange={this.onChangehandler}
                                                                />
                                                                {this.state.currShowPassword ?
                                                                    <span className="ad-fa-eye-pass"> <i onClick={() => this.currShowPassword()} className="fas fa-eye-slash"></i> </span>
                                                                    :
                                                                    <span className="ad-fa-eye-pass"> <i onClick={() => this.currShowPassword()} className="fas fa-eye"></i> </span>
                                                                }
                                                            </div>
                                                            <span className="text-danger">{this.state.errMsg.current_password}</span>
                                                        </div>

                                                        <div class="form-group col-lg-12 col-md-12">
                                                            <label>New Password</label>
                                                            <div className="position-relative">
                                                                <input
                                                                    className="form-control"
                                                                    required=""
                                                                    type={this.state.newShowPassword ? "text" : "password"}
                                                                    name="password"
                                                                    placeholder="New Password"
                                                                    value={this.state.password}
                                                                    onChange={this.onChangehandler}
                                                                />
                                                                {this.state.newShowPassword ?
                                                                    <span className="ad-fa-eye-pass"> <i onClick={() => this.newShowPassword()} className="fas fa-eye-slash"></i> </span>
                                                                    :
                                                                    <span className="ad-fa-eye-pass"> <i onClick={() => this.newShowPassword()} className="fas fa-eye"></i> </span>
                                                                }
                                                            </div>
                                                            <span className="text-danger">{this.state.errMsg.password}</span>
                                                        </div>

                                                        <div class="form-group col-lg-12 col-md-12">
                                                            <label>Confirm Password</label>
                                                            <div className="position-relative">
                                                                <input
                                                                    className="form-control"
                                                                    required=""
                                                                    type={this.state.confirmShowPassword ? "text" : "password"}
                                                                    name="confirm_password"
                                                                    placeholder="Confirm Password"
                                                                    value={this.state.confirm_password}
                                                                    onChange={this.onChangehandler}
                                                                />
                                                                {this.state.confirmShowPassword ?
                                                                    <span className="ad-fa-eye-pass"> <i onClick={() => this.confirmShowPassword()} className="fas fa-eye-slash"></i> </span>
                                                                    :
                                                                    <span className="ad-fa-eye-pass"> <i onClick={() => this.confirmShowPassword()} className="fas fa-eye"></i> </span>
                                                                }
                                                            </div>
                                                            <span className="text-danger">{this.state.errMsg.confirm_password}</span>

                                                        </div>
                                                        <div class=" col-lg-12 col-md-12">
                                                            <Button
                                                                color="primary"
                                                                className="btn btn-primary rounded"
                                                                onClick={() => this.onSubmitHandler()}
                                                            >Save Changes</Button>
                                                        </div>
                                                    </div>

                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </section>
                    <Footer />
                </div>
            </>
        )
    }
}

