import React, { Component } from 'react'
import { Button ,Spinner} from 'reactstrap'
import axios from "axios";
import { APIURL } from '../../../../components/constants/common';
// import { Helmet } from "react-helmet";
import Map from '../Map/index'
import PlacesAutocomplete, {  geocodeByAddress,   getLatLng, } from 'react-places-autocomplete';

export default class PropertyInfo extends Component {
    constructor() {
        super();

        this.state = {
            token: JSON.parse(localStorage.getItem("token")),
            user: JSON.parse(localStorage.getItem("userData")),
            userInfo: {
                streetNumber: "",
                streetName: "",
                AptNumber: "",
                state: "",
                city: "",
                zip: "",
                map: ""
            },
            countryId: "",
            countries_name: [],
            Languages: [],
            Countries: [],
            States: [],
            state_name: [],
            state: "",
            name: "",
            image: "",
            selectType: "",
            errMsg: {},
            scsMsg: "",
            country_id: "",
            address: '',
            lat:"",
            long:""
        }
    }

    componentDidMount() {
        this.getCountries()
        this.getAddressInfo()
    }

    handleChange = address => {
        this.setState({ address });
      };
     
      handleSelect = address => {
        geocodeByAddress(address)
          .then(results => getLatLng(results[0]))
          .then(latLng => 
            this.setState({
                lat:latLng.lat,
                long:latLng.lng
            })
            )
          .catch(error => console.error('Error', error));
      };

    onChangehandler = (e, key) => {
        const { userInfo } = this.state;
        userInfo[e.target.name] = e.target.value;
        this.setState({
            userInfo,
            errMsg: ""
        });
        console.log(userInfo)
    };

    getCountries() {
        axios
            .get(APIURL + "countries")
            .then((response) => {
                let countries_name = response.data.countries;
                const CountryNames = [];
                for (var c = 1; c < countries_name.length; c++) {
                    CountryNames.push({ value: countries_name[c].id, label: countries_name[c].name })
                }
                this.setState({
                    Countries: CountryNames,
                })
                console.log(this.state.Countries)
            })
    }

    handleCountry(e) {
        this.setState({
            countryId: e
        }, () => {
            console.log(this.state.countryId)
            this.handleCountryState(e)
        })
    };

    // get states
    handleCountryState = (id) => {
        axios
            .post(APIURL + "states", {
                country_id: id,
            })
            .then((response) => {
                console.log(response.data)
                let state_name = response.data.states;
                const stateNames = [];
                for (var c = 0; c < state_name.length; c++) {
                    stateNames.push({ value: state_name[c].id, label: state_name[c].name })
                }
                this.setState({
                    States: stateNames,
                })
            })
            .catch((error) => {
                this.setState({

                })
            });
    };

    // handle states
    handleState(e) {
        this.setState({
            stateId: e
        })
    }

    getAddressInfo() {
        if (this.state.user) {
            const formData = new FormData();
            // formData.append('token', this.state.token);
            formData.append('id', this.props.data.property_id);
            var token = this.state.token
            axios
                .post(APIURL + "seller/property-address-edit", formData, {
                    headers: {
                        'Authorization': `Bearer ${token}`
                    }
                })
                .then((response) => {
                    const info = response.data.data;
                    // this.setState({
                    //     userInfo: {
                    //         streetNumber: info.street_number,
                    //         streetName: info.street_name,
                    //         AptNumber: info.apt_number,
                    //         city: info.city,
                    //         zip: info.zip,
                    //         map: info.map
                    //     },
                    //     countryId:info.country,
                    //     stateId:info.state,
                    // })
                    this.setState({
                        userInfo: {
                            streetNumber: info.street_number === "null" ? "" :info.street_number,
                            streetName: info.street_name === "null" ? "" :info.street_name,
                            AptNumber: info.apt_number === "null" ? "" :info.apt_number,
                            city: info.city === "null" ? "" :info.city,
                            zip: info.zip === "null" ? "" :info.zip,
                            map: info.map === "null" ? "" :info.map
                        },
                        countryId:info.country === "null" ? "" :info.country,
                        stateId:info.state === "null" ? "" :info.state,
                    })
                    this.handleCountryState(this.state.countryId)
                    console.log("sssssssss", this.state.stateId)
                })
                .catch((error) => {
                    this.setState({
                        errMsg: error.response.data.errors,
                        Loader: false
                    })
                });
        }
    }
    
    onSubmitHandler = (e) => {
        var token = this.state.token
        const { userInfo ,user } = this.state;
        const formData = new FormData();
        formData.append('street_number', this.state.userInfo.streetNumber);
        formData.append('street_name', this.state.userInfo.streetName);
        formData.append('apt_number', this.state.userInfo.AptNumber);
        formData.append('state', this.state.stateId);
        formData.append('country', this.state.countryId);
        formData.append('city', this.state.userInfo.city);
        formData.append('zip', this.state.userInfo.zip);
        formData.append('map', this.state.userInfo.map);
        formData.append('property_id', this.props.data.property_id);
        formData.append('lat', this.state.lat);
        formData.append('long', this.state.long);
        this.setState({ Loader: true });
        axios
            .post(APIURL + "seller/property-address-update", formData, {
                headers: {
                    'Authorization': `Bearer ${token}`
                }
            })
            .then((response) => {
                this.setState({ Loader: false });
                this.setState({
                    errMsg: {},
                }, () => {
                    this.props.data.handleActiveTab("3");
                });
            })
            .catch((error) => {
                this.setState({
                    errMsg: error.response.data.error ,
                    Loader: false
                })
            });
    };
    render() {
        console.log("address",this.props.data.property_id)
        return (
            <>
            {/* <Helmet>
                    <link rel="stylesheet" href="http://192.168.1.13/custom.css" />
                </Helmet> */}
             {this.state.Loader ? <div className="loader"> <Spinner type="grow" color="dark" style={{ width: '3rem', height: '3rem' }} /> </div> : ""}
                {this.state.errMsg.message ?
                <div class="alert alert-danger text-center" role="alert">
                {this.state.errMsg.message}
               </div>
               :""} 
                <div className="card mt-4">
                    <div className="">
                        <form class="forms-sample ">
                            <div className="row">
                                <div class="form-group col-6 ">
                                    <label for="exampleInputName1">Street Number <strong className="text-danger" >*</strong> </label>
                                    <input
                                        autoFocus={true}
                                        className="form-control"
                                        required=""
                                        type="number"
                                        min="0"
                                        name="streetNumber"
                                        placeholder="Street Number"
                                        value={this.state.userInfo.streetNumber}
                                        onChange={this.onChangehandler}
                                    />
                                    <span className="text-danger">{this.state.errMsg.street_number}</span>
                                </div>
                                <div class="form-group col-6">
                                    <label for="exampleInputEmail3">Street Name </label>
                                    <input
                                        autoFocus={true}
                                        className="form-control"
                                        required=""
                                        type="text"
                                        name="streetName"
                                        placeholder="Street Name"
                                        value={this.state.userInfo.streetName}
                                        onChange={this.onChangehandler}
                                    />
                                     <span className="text-danger">{this.state.errMsg.street_name}</span>
                                </div>
                                <div class="form-group col-6">
                                    <label for="exampleInputPassword4">Apartment Number</label>
                                    <input
                                        autoFocus={true}
                                        className="form-control"
                                        required=""
                                        type="number"
                                        min="0"
                                        name="AptNumber"
                                        placeholder="Apartment Number"
                                        value={this.state.userInfo.AptNumber}
                                        onChange={this.onChangehandler}
                                    /> 
                                    <span className="text-danger">{this.state.errMsg.apt_number}</span> </div>
                                <div class="form-group col-6">
                                    <label for="exampleSelectGender">Country<strong className="text-danger" >*</strong></label>
                                    <select className="form-control" value={this.state.countryId} onChange={(e) => this.handleCountry(e.target.value)} >
                                        <option value="">Select</option>
                                        {this.state.Countries.map((option) => (
                                            <option value={option.value}>{option.label}</option>
                                        ))}
                                    </select>
                                     <span className="text-danger">{this.state.errMsg.country}</span>
                                </div>
                                <div class="form-group col-6">
                                    <label for="exampleInputPassword4">State<strong className="text-danger" >*</strong></label>
                                    <select className="form-control" value={this.state.stateId} onChange={(e) => this.handleState(e.target.value)} >
                                        <option value="" >Select</option>
                                        {this.state.States.map((option) => (
                                            <option value={option.value}>{option.label}</option>
                                        ))}
                                    </select>
                                     <span className="text-danger">{this.state.errMsg.state}</span>
                                </div>
                                <div class="form-group col-6">
                                    <label for="exampleInputPassword4">City</label>
                                    <input
                                        autoFocus={true}
                                        className="form-control"
                                        required=""
                                        type="text"
                                        name="city"
                                        placeholder="City"
                                        value={this.state.userInfo.city}
                                        onChange={this.onChangehandler}
                                    />
                                     <span className="text-danger">{this.state.errMsg.city}</span>
                                </div>
                                <div class="form-group col-6">
                                    <label for="exampleInputPassword4">Zip</label>
                                    <input
                                        autoFocus={true}
                                        className="form-control"
                                        required=""
                                        type="number"
                                        min="0"
                                        name="zip"
                                        placeholder="Zip"
                                        value={this.state.userInfo.zip}
                                        onChange={this.onChangehandler}
                                    />
                                     <span className="text-danger">{this.state.errMsg.zip}</span>
                                </div>
                                
                                <div class="form-group col-6">
                                    <label for="exampleInputPassword4">Address</label>
                                    <PlacesAutocomplete
                                        value={this.state.address}
                                        onChange={this.handleChange}
                                        onSelect={this.handleSelect}
                                    >
                                        {({ getInputProps, suggestions, getSuggestionItemProps, loading }) => (
                                        <div>
                                            <input
                                            {...getInputProps({
                                                placeholder: 'Search Places ...',
                                                className: 'location-search-input form-control',
                                            })}
                                            />
                                            <div className="autocomplete-dropdown-container">
                                            {loading && <div>Loading...</div>}
                                            {suggestions.map(suggestion => {
                                                const className = suggestion.active
                                                ? 'suggestion-item--active'
                                                : 'suggestion-item';
                                                // inline style for demonstration purpose
                                                const style = suggestion.active
                                                ? { backgroundColor: '#fafafa', cursor: 'pointer' }
                                                : { backgroundColor: '#ffffff', cursor: 'pointer' };
                                                return (
                                                <div
                                                    {...getSuggestionItemProps(suggestion, {
                                                    className,
                                                    style,
                                                    })}
                                                >
                                                    <span>{suggestion.description}</span>
                                                </div>
                                                );
                                            })}
                                            </div>
                                        </div>
                                        )}
                                    </PlacesAutocomplete>
                                  </div>
                            </div>
                            {/* <div className="row">
                                <div class="form-group col-12">
                                   <Map />
                                   </div>
                            </div> */}
                            <div className="row">
                                <div class="form-group col-6">
                                    <Button className="btn btn-success mr-1" onClick={(e) => this.props.data.handleActiveTab("1")} ><i class="mdi mdi-arrow-left me-1"></i>Back to information</Button>
                                    <Button className="btn btn-info" onClick={(e) => this.onSubmitHandler()}  >Go to Features <i class="mdi mdi-arrow-right ms-1"></i></Button>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
            </>
        )
    }
}
