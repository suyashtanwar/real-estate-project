import React, { Component } from 'react'
import face1 from '../../../assets/images/faces/dummy.png'
import { Link, Redirect } from 'react-router-dom'
import axios from 'axios';
import { Tooltip } from 'reactstrap';
import { APIURL, BASEURL } from '../../../components/constants/common';

export default class Sidebar extends Component {
    constructor(props) {
        super(props);
        this.state = {
            // stylePath:true,
            sidebarClass: "sidebar-icon-only",
            token: JSON.parse(localStorage.getItem("token")),
            user: JSON.parse(localStorage.getItem("userData")),
            profile_image: "",
            dashboard: false,
            myProfile: false,
            property: false,
            enquiry: false,
            agentreq: false,
            changePass: false,
            reload:false,
            // user:false
        }
    }

     
   

    getProfileInfo() {
        if (this.state.user) {
            const formData = new FormData();
            // formData.append('token', this.state.token);
            formData.append('id', this.state.user.id);
            var token = this.state.token
            var app_url = APIURL+"agent/edit-profile"
            axios
                .post(app_url, formData, {
                    headers: {
                        'Authorization': `Bearer ${token}`
                    }
                })
                .then((response) => {
                    const info = response.data.data;
                    this.setState({
                        profile_image: response.data.data.url_path,
                        name: response.data.data.name
                    })
                    console.log("bjsbvjx", this.state.profile_image)
                })
                .catch((error) => {
                    this.setState({
                        // errMsg: error.response.data.errors,
                        Loader: false
                    })
                });
        }
    }

    dashboard = () => { this.setState({ dashboard: !this.state.dashboard }) }
    myProfile = () => { this.setState({ myProfile: !this.state.myProfile }) }
    property = () => { this.setState({ property: !this.state.property }) }
    enquiry = () => { this.setState({ enquiry: !this.state.enquiry }) }
    agentreq = () => { this.setState({ agentreq: !this.state.agentreq }) }
    changePass = () => { this.setState({ changePass: !this.state.changePass }) }

    componentDidMount() {
        console.log("componentDidMount")
        this.getProfileInfo()
         /*   require("../../../admin_css/css/style.css");
            require("../../../admin_css/css/custom.css");
            require("../../../admin_css/vendors/mdi/css/materialdesignicons.min.css");
            require("../../../admin_css/vendors/css/vendor.bundle.base.css");*/
        
    }

    render() {
        const { user, name } = this.state
        if (!this.state.user) {
            return <Redirect to="/signin" />;
        }
        if (this.state.user.user_type !== "Seller") {
            return <Redirect to="/permission" />;
        }
        return (
            <>
                <nav class="sidebar sidebar-offcanvas" id="sidebar">
                    <ul class="nav">
                        <li class="nav-item nav-profile">
                            <a href="#" class="nav-link">
                                <div class="nav-profile-image">
                                    <img src={this.state.profile_image ? this.state.profile_image : face1} alt="profile" />
                                    <span class="login-status online"></span>
                                </div>
                                <div class="nav-profile-text d-flex flex-column">
                                    <span class="font-weight-bold mb-2">{name}</span>
                                    <span class="text-secondary text-small st">Seller</span>
                                </div>
                                <i class="mdi mdi-bookmark-check text-success nav-profile-badge"></i>
                            </a>
                        </li>
                        <li className={this.props.activePage === "dashboard" ? "nav-item active" : "nav-item"}>
                            <Link id="dashboard" class="nav-link" to="/seller">
                                <span class="menu-title">Dashboard</span>
                                <i class="fas fa-home menu-icon"></i>
                                {document.body.classList.contains(this.state.sidebarClass) ?
                                    <Tooltip placement="right" isOpen={this.state.dashboard} autohide={false} target="dashboard" toggle={this.dashboard}>
                                        DashBoard
                                    </Tooltip>
                                    : ""}
                            </Link>
                        </li>
                        <li className={this.props.activePage === "profile" ? "nav-item active" : "nav-item"}>
                            <Link id="profile" class="nav-link" to="/seller/profile">
                                <span class="menu-title">My Profile</span>
                                <i  className="fas fa-user-tie menu-icon"></i>
                                {document.body.classList.contains(this.state.sidebarClass) ?
                                    <Tooltip placement="right" isOpen={this.state.myProfile} autohide={false} target="profile" toggle={this.myProfile}>
                                        My profile
                                    </Tooltip> : ""}
                            </Link>
                        </li>
                        <li  className={this.props.activePage === "property_list" ? "nav-item active" : "nav-item"}>
                            <Link id="Property"
                                class="nav-link"
                                to="/seller/property"
                            >
                                <span class="menu-title">Property</span>
                                <i class="far fa-building menu-icon"></i>
                                {document.body.classList.contains(this.state.sidebarClass) ?
                                    <Tooltip placement="right" isOpen={this.state.property} autohide={false} target="Property" toggle={this.property}>
                                        Properties
                                    </Tooltip> : ""}
                            </Link>
                        </li>
                        <li className={this.props.activePage === "Enquiry" ? "nav-item active" : "nav-item"}>
                            <Link id="Enquiry" class="nav-link" to="/seller/enquiry">
                                <span class="menu-title">Property Enquiry</span>
                                <i id="Enquiry" class="fas fa-book-reader menu-icon"></i>
                                {document.body.classList.contains(this.state.sidebarClass) ?
                                    <Tooltip placement="right" isOpen={this.state.enquiry} autohide={false} target="Enquiry" toggle={this.enquiry}>
                                        Enquiry
                                    </Tooltip> : ""}
                            </Link>
                        </li>
                        <li className={this.props.activePage === "change_password" ? "nav-item active" : "nav-item"}>
                            <Link id="Password" class="nav-link" to="/seller/changepassword">
                                <span class="menu-title">Change Password</span>
                                <i class="fas fa-key menu-icon"></i>
                                {document.body.classList.contains(this.state.sidebarClass) ?
                                    <Tooltip placement="right" isOpen={this.state.changePass} autohide={false} target="Password" toggle={this.changePass}>
                                        Change Password
                                    </Tooltip> : ""}
                            </Link>
                        </li>
                    </ul>
                </nav>
            </>
        )
    }
}
