import React, { Component } from 'react'
import face1 from '../../../assets/images/faces/dummy.png'
import { Link, Redirect } from 'react-router-dom'
import axios from 'axios';
import { Tooltip } from 'reactstrap';
import { APIURL } from '../../../components/constants/common';

export default class Sidebar extends Component {
    constructor(props) {
        super(props);
        this.state = {
            sidebarClass: "sidebar-icon-only",
            token: JSON.parse(localStorage.getItem("token")),
            user: JSON.parse(localStorage.getItem("userData")),
            profile_image: "",
            dashboard: false,
            myProfile: false,
            property: false,
            enquiry: false,
            agentreq: false,
            changePass: false,
        }
    }
    componentDidMount() {
        this.getProfileInfo()
        console.log(this.state.user_type)
    }

    getProfileInfo() {
        if (this.state.user) {
            const formData = new FormData();
            // formData.append('token', this.state.token);
            formData.append('id', this.state.user.id);
            var token = this.state.token
            var app_url = APIURL+"admin/edit-profile"
            axios
                .post(app_url, formData, {
                    headers: {
                        'Authorization': `Bearer ${token}`
                    }
                })
                .then((response) => {
                    const info = response.data.data;
                    this.setState({
                        profile_image: response.data.data.url_path,
                        name: response.data.data.name
                    })

                })
                .catch((error) => {
                    this.setState({
                        // errMsg: error.response.data.errors,
                        Loader: false
                    })
                });
        }
    }
    dashboard = () => { this.setState({ dashboard: !this.state.dashboard }) }
    myProfile = () => { this.setState({ myProfile: !this.state.myProfile }) }
    property = () => { this.setState({ property: !this.state.property }) }
    enquiry = () => { this.setState({ enquiry: !this.state.enquiry }) }
    agentreq = () => { this.setState({ agentreq: !this.state.agentreq }) }
    changePass = () => { this.setState({ changePass: !this.state.changePass }) }
    AssignProperty = () => { this.setState({ AssignProperty: !this.state.AssignProperty }) }

    render() {
        const { user, name } = this.state

        if (!this.state.user) {
            alert("please log in")
            return <Redirect to="/signin" />;
        }
       
        if (this.state.user.user_type !== "Admin") {
            return <Redirect to="/permission" />;
        }
        return (
            <>
                <nav className="sidebar sidebar-offcanvas" id="sidebar">
                    <ul className="nav">
                        <li className="nav-item nav-profile">
                            <a href="#" className="nav-link">
                                <div className="nav-profile-image">
                                    <img src={this.state.profile_image !== "" ? this.state.profile_image : face1} alt="profile" />
                                    <span className="login-status online"></span>
                                </div>
                                <div className="nav-profile-text d-flex flex-column">
                                    <span className="font-weight-bold mb-2">{name}</span>
                                    <span className="text-secondary text-small">Admin Panel</span>
                                </div>
                                <i className="mdi mdi-bookmark-check text-success nav-profile-badge"></i>
                            </a>
                        </li>
                        <li className={this.props.activePage === "dashboard" ? "nav-item active" : "nav-item"}>
                            <Link id="dashboard" className="nav-link" to="/admin">
                                <span className="menu-title">Dashboard</span>
                                <i class="fas fa-home menu-icon"></i>
                                {document.body.classList.contains(this.state.sidebarClass) ?
                                    <Tooltip placement="right" isOpen={this.state.dashboard} autohide={false} target="dashboard" toggle={this.dashboard}>
                                        DashBoard
                                    </Tooltip>
                                    : ""
                                }
                            </Link>
                        </li>
                        <li className={this.props.activePage === "profile" ? "nav-item active" : "nav-item"}>
                            <Link id="profile" className="nav-link" to="/admin/profile">
                                <span className="menu-title">My profile</span>
                                <i className="fas fa-user-tie menu-icon"></i>
                                {document.body.classList.contains(this.state.sidebarClass) ?
                                    <Tooltip placement="right" isOpen={this.state.myProfile} autohide={false} target="profile" toggle={this.myProfile}>
                                        My profile
                                    </Tooltip> : ""}

                            </Link>
                        </li>
                        <li className={this.props.activePage === "property" ? "nav-item active" : "nav-item"}>
                            <Link id="Property" className="nav-link" to="/admin/property">
                                <span className="menu-title">Property</span>
                                <i className="far fa-building menu-icon"></i>
                                {document.body.classList.contains(this.state.sidebarClass) ?
                                    <Tooltip placement="right" isOpen={this.state.property} autohide={false} target="Property" toggle={this.property}>
                                        Property
                                    </Tooltip> : ""}
                            </Link>
                        </li>
                        <li className={this.props.activePage === "enquiry" ? "nav-item active" : "nav-item"}>
                            <Link id="Enquiry" className="nav-link" to="/admin/enquiry">
                                <span className="menu-title">Property Enquiry</span>
                                <i className="fas fa-book-reader menu-icon"></i>
                                {document.body.classList.contains(this.state.sidebarClass) ?
                                    <Tooltip placement="right" isOpen={this.state.enquiry} autohide={false} target="Enquiry" toggle={this.enquiry}>
                                        Enquiry
                                    </Tooltip> : ""}
                            </Link>
                        </li>
                        <li className={this.props.activePage === "agent_request" ? "nav-item active" : "nav-item"}>
                            <Link id="Request" className="nav-link" to="/admin/approval">
                                <span className="menu-title">Agent Request</span>
                                <i className="fas fa-users menu-icon"></i>
                                {document.body.classList.contains(this.state.sidebarClass) ?
                                    <Tooltip placement="right" isOpen={this.state.agentreq} autohide={false} target="Request" toggle={this.agentreq}>
                                        Agent Request
                                    </Tooltip> : ""}
                            </Link>
                        </li>
                        {/* <li className={this.props.activePage === "Verified" ? "nav-item active" : "nav-item"}>
                            <Link id="Verified" className="nav-link" to="/admin/verified/property">
                                <span className="menu-title">Verified Property</span>
                                <i class="fas fa-file-signature menu-icon"></i>
                                {document.body.classList.contains(this.state.sidebarClass) ?
                                    <Tooltip placement="right" isOpen={this.state.AssignProperty} autohide={false} target="Verified" toggle={this.VerifiedProperty()}>
                                        Verified Property
                                    </Tooltip> : ""}
                            </Link>
                        </li> */}
                        <li className={this.props.activePage === "assigned_property" ? "nav-item active" : "nav-item"}>
                            <Link id="Assign_Property" className="nav-link" to="/admin/assign/property">
                                <span className="menu-title">Assign Property</span>
                                <i class="fas fa-file-signature menu-icon"></i>
                                {document.body.classList.contains(this.state.sidebarClass) ?
                                    <Tooltip placement="right" isOpen={this.state.AssignProperty} autohide={false} target="Assign_Property" toggle={this.AssignProperty}>
                                        Assign Property
                                    </Tooltip> : ""}
                            </Link>
                        </li>
                        <li className={this.props.activePage === "password" ? "nav-item active" : "nav-item"}>
                            <Link id="Password" className="nav-link" to="/admin/changepassword">
                                <span className="menu-title">Change Password</span>
                                <i className="fas fa-key menu-icon"></i>
                                {document.body.classList.contains(this.state.sidebarClass) ?
                                    <Tooltip placement="right" isOpen={this.state.changePass} autohide={false} target="Password" toggle={this.changePass}>
                                        Change Password
                                    </Tooltip> : ""}
                            </Link>
                        </li>
                    </ul>
                </nav>
            </>
        )
    }
}
