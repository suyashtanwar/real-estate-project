import React, { Component } from 'react'
import logo from '../../../../assets/img/logo.png'

export default class Index extends Component {
    render() {
        return (
            <div>
                <div id="main-wrapper">

                    <div class="header header-light head-shadow">
                        <div class="container">
                            <nav id="navigation" class="navigation navigation-landscape">
                                <div class="nav-header">
                                    <a class="nav-brand" href="#">
                                        <img src={logo} class="logo" alt="" />
                                    </a>
                                    <div class="nav-toggle"></div>
                                </div>
                                <div class="nav-menus-wrapper" style={{ transitionProperty: "none" }}>
                                    <ul class="nav-menu">

                                        <li class="active"><a href="#">Home<span class="submenu-indicator"></span></a>
                                            <ul class="nav-dropdown nav-submenu">
                                                <li><a class="active" href="index.html">Home Layout 1</a></li>
                                                <li><a href="home-2.html">Home Layout 2</a></li>
                                                <li><a href="home-3.html">Home Layout 3</a></li>
                                                <li><a href="home-4.html">Home Layout 4</a></li>
                                                <li><a href="home-5.html">Home Layout 5</a></li>
                                                <li><a href="home-6.html">Home Layout 6</a></li>
                                                <li><a href="home-7.html">Home Layout 7</a></li>
                                                <li><a href="home-8.html">Home Layout 8</a></li>
                                                <li><a href="map.html">Map Home Layout</a></li>
                                            </ul>
                                        </li>

                                        <li><a href="JavaScript:Void(0);">Listings<span class="submenu-indicator"></span></a>
                                            <ul class="nav-dropdown nav-submenu">
                                                <li><a href="JavaScript:Void(0);">List Layout<span class="submenu-indicator"></span></a>
                                                    <ul class="nav-dropdown nav-submenu">
                                                        <li><a href="list-layout-with-sidebar.html">With Sadebar</a></li>
                                                        <li><a href="list-layout-with-map.html">With Map</a></li>
                                                        <li><a href="list-layout-full.html">Full Width</a></li>
                                                    </ul>
                                                </li>
                                                <li><a href="JavaScript:Void(0);">Grid Layout<span class="submenu-indicator"></span></a>
                                                    <ul class="nav-dropdown nav-submenu">
                                                        <li><a href="grid-layout-with-sidebar.html">With Sidebar</a></li>
                                                        <li><a href="classical-layout-with-sidebar.html">Classical With Sidebar</a></li>
                                                        <li><a href="grid-layout-with-map.html">With Map</a></li>
                                                        <li><a href="grid.html">Full Width</a></li>
                                                        <li><a href="classical-property.html">Classical Full Width</a></li>
                                                    </ul>
                                                </li>
                                                <li><a href="JavaScript:Void(0);">With Map Property<span class="submenu-indicator"></span></a>
                                                    <ul class="nav-dropdown nav-submenu">
                                                        <li><a href="list-layout-with-map.html">List With Map</a></li>
                                                        <li><a href="grid-layout-with-map.html">Grid With Map</a></li>
                                                        <li><a href="classical-layout-with-map.html">Classical With Map</a></li>
                                                        <li><a href="half-map.html">Half Map Search</a></li>
                                                    </ul>
                                                </li>
                                            </ul>
                                        </li>

                                        <li><a href="JavaScript:Void(0);">Features<span class="submenu-indicator"></span></a>
                                            <ul class="nav-dropdown nav-submenu">
                                                <li><a href="JavaScript:Void(0);">Single Property<span class="submenu-indicator"></span></a>
                                                    <ul class="nav-dropdown nav-submenu">
                                                        <li><a href="single-property-1.html">Single Property 1</a></li>
                                                        <li><a href="single-property-2.html">Single Property 2</a></li>
                                                        <li><a href="single-property-3.html">Single Property 3</a></li>
                                                    </ul>
                                                </li>
                                                <li><a href="JavaScript:Void(0);">Agencies & Agents<span class="submenu-indicator"></span></a>
                                                    <ul class="nav-dropdown nav-submenu">
                                                        <li><a href="agents.html">Agents List</a></li>
                                                        <li><a href="agent-page.html">Agent Page</a></li>
                                                        <li><a href="agencies.html">Agencies List</a></li>
                                                        <li><a href="agency-page.html">Agency Page</a></li>
                                                    </ul>
                                                </li>
                                                <li><a href="JavaScript:Void(0);">My Account<span class="submenu-indicator"></span></a>
                                                    <ul class="nav-dropdown nav-submenu">
                                                        <li><a href="dashboard.html">User Dashboard</a></li><li><a href="payment.html">Payment Confirmation</a></li>
                                                        <li><a href="my-profile.html">My Profile</a></li>
                                                        <li><a href="my-property.html">Property List</a></li>
                                                        <li><a href="bookmark-list.html">Bookmarked Listings</a></li>
                                                        <li><a href="change-password.html">Change Password</a></li>
                                                    </ul>
                                                </li>
                                                <li>
                                                    <a href="compare-property.html">Compare Property</a>
                                                </li>
                                                <li>
                                                    <a href="submit-property.html">Submit Property</a>
                                                </li>
                                            </ul>
                                        </li>

                                        <li><a href="JavaScript:Void(0);">Pages<span class="submenu-indicator"></span></a>
                                            <ul class="nav-dropdown nav-submenu">
                                                <li><a href="blog.html">Blogs Page</a></li>
                                                <li><a href="blog-detail.html">Blog Detail</a></li>
                                                <li><a href="component.html">Shortcodes</a></li>
                                                <li><a href="pricing.html">Pricing</a></li>
                                                <li><a href="404.html">Error Page</a></li>
                                                <li><a href="contact.html">Contacts</a></li>
                                            </ul>
                                        </li>

                                        <li><a href="JavaScript:Void(0);" data-bs-toggle="modal" data-bs-target="#signup">Sign Up</a></li>

                                    </ul>

                                    <ul class="nav-menu nav-menu-social align-to-right">
                                        <li>
                                            <a href="index.html"><img src="assets/img/off.svg" class="mr-2" width="17" alt="" />Sign Out</a>
                                        </li>
                                    </ul>

                                </div>
                            </nav>
                        </div>
                    </div>
                    <div class="clearfix"></div>

                    <div class="page-title">
                        <div class="container">
                            <div class="row">
                                <div class="col-lg-12 col-md-12">

                                    <h2 class="ipt-title">Welcome!</h2>
                                    <span class="ipn-subtitle">Welcome To Your Account</span>

                                </div>
                            </div>
                        </div>
                    </div>

                    <section class="bg-light">
                        <div class="container-fluid">
                            <div class="row">
                                <div class="col-lg-12 col-md-12">
                                    <div class="filter_search_opt">
                                        <a href="javascript:void(0);" onclick="openFilterSearch()">Dashboard Navigation<i class="ml-2 ti-menu"></i></a>
                                    </div>
                                </div>
                            </div>

                            <div class="row">

                                <div class="col-lg-3 col-md-12">

                                    <div class="simple-sidebar sm-sidebar" id="filter_search">

                                        <div class="search-sidebar_header">
                                            <h4 class="ssh_heading">Close Filter</h4>
                                            <button onclick="closeFilterSearch()" class="w3-bar-item w3-button w3-large"><i class="ti-close"></i></button>
                                        </div>

                                        <div class="sidebar-widgets">
                                            <div class="dashboard-navbar">

                                                <div class="d-user-avater">
                                                    <img src="assets/img/user-3.jpg" class="img-fluid avater" alt="" />
                                                    <h4>Adam Harshvardhan</h4>
                                                    <span>Canada USA</span>
                                                </div>

                                                <div class="d-navigation">
                                                    <ul>
                                                        <li><a href="dashboard.html"><i class="ti-dashboard"></i>Dashboard</a></li>
                                                        <li class="active"><a href="my-profile.html"><i class="ti-user"></i>My Profile</a></li>
                                                        <li><a href="bookmark-list.html"><i class="ti-bookmark"></i>Bookmarked Listings</a></li>
                                                        <li><a href="my-property.html"><i class="ti-layers"></i>My Properties</a></li>
                                                        <li><a href="submit-property-dashboard.html"><i class="ti-pencil-alt"></i>Submit New Property</a></li>
                                                        <li><a href="change-password.html"><i class="ti-unlock"></i>Change Password</a></li>
                                                        <li><a href="#"><i class="ti-power-off"></i>Log Out</a></li>
                                                    </ul>
                                                </div>

                                            </div>
                                        </div>

                                    </div>
                                </div>

                                <div class="col-lg-9 col-md-12">
                                    <div class="dashboard-wraper">

                                        <div class="form-submit">
                                            <h4>My Account</h4>
                                            <div class="submit-section">
                                                <div class="row">

                                                    <div class="form-group col-md-6">
                                                        <label>Your Name</label>
                                                        <input type="text" class="form-control" value="Shaurya Preet" />
                                                    </div>

                                                    <div class="form-group col-md-6">
                                                        <label>Email</label>
                                                        <input type="email" class="form-control" value="preet77@gmail.com" />
                                                    </div>

                                                    <div class="form-group col-md-6">
                                                        <label>Your Title</label>
                                                        <input type="text" class="form-control" value="Web Designer" />
                                                    </div>

                                                    <div class="form-group col-md-6">
                                                        <label>Phone</label>
                                                        <input type="text" class="form-control" value="123 456 5847" />
                                                    </div>

                                                    <div class="form-group col-md-6">
                                                        <label>Address</label>
                                                        <input type="text" class="form-control" value="522, Arizona, Canada" />
                                                    </div>

                                                    <div class="form-group col-md-6">
                                                        <label>City</label>
                                                        <input type="text" class="form-control" value="Montquebe" />
                                                    </div>

                                                    <div class="form-group col-md-6">
                                                        <label>State</label>
                                                        <input type="text" class="form-control" value="Canada" />
                                                    </div>

                                                    <div class="form-group col-md-6">
                                                        <label>Zip</label>
                                                        <input type="text" class="form-control" value="160052" />
                                                    </div>

                                                    <div class="form-group col-md-12">
                                                        <label>About</label>
                                                        <textarea class="form-control">Maecenas quis consequat libero, a feugiat eros. Nunc ut lacinia tortor morbi ultricies laoreet ullamcorper phasellus semper</textarea>
                                                    </div>

                                                </div>
                                            </div>
                                        </div>

                                        <div class="form-submit">
                                            <h4>Social Accounts</h4> /
                                            <div class="submit-section">
                                                <div class="row">

                                                    <div class="form-group col-md-6">
                                                        <label>Facebook</label>
                                                        <input type="text" class="form-control" value="https://facebook.com/" />
                                                    </div>

                                                    <div class="form-group col-md-6">
                                                        <label>Twitter</label>
                                                        <input type="email" class="form-control" value="https://twitter.com/" />
                                                    </div>

                                                    <div class="form-group col-md-6">
                                                        <label>Google Plus</label>
                                                        <input type="text" class="form-control" value="https://googleplus.com" />
                                                    </div>

                                                    <div class="form-group col-md-6">
                                                        <label>LinkedIn</label>
                                                        <input type="text" class="form-control" value="https://linkedin.com/" />
                                                    </div>

                                                    <div class="form-group col-lg-12 col-md-12">
                                                        <button class="btn btn-theme-light-2 rounded" type="submit">Save Changes</button>
                                                    </div>

                                                </div>
                                            </div>
                                        </div>

                                    </div>
                                </div>

                            </div>
                        </div>
                    </section>

                    <section class="theme-bg call-to-act-wrap">
                        <div class="container">
                            <div class="row">
                                <div class="col-lg-12">

                                    <div class="call-to-act">
                                        <div class="call-to-act-head">
                                            <h3>Want to Become a Real Estate Agent?</h3>
                                            <span>We'll help you to grow your career and growth.</span>
                                        </div>
                                        <a href="#" class="btn btn-call-to-act">SignUp Today</a>
                                    </div>

                                </div>
                            </div>
                        </div>
                    </section>

                    <footer class="dark-footer skin-dark-footer">
                        <div>
                            <div class="container">
                                <div class="row">

                                    <div class="col-lg-3 col-md-3">
                                        <div class="footer-widget">
                                            <img src="assets/img/logo-light.png" class="img-footer" alt="" />
                                            <div class="footer-add">
                                                <p>Collins Street West, Victoria 8007, Australia.</p>
                                                <p>+1 246-345-0695</p>
                                                <p>info@example.com</p>
                                            </div>

                                        </div>
                                    </div>
                                    <div class="col-lg-2 col-md-2">
                                        <div class="footer-widget">
                                            <h4 class="widget-title">Navigations</h4>
                                            <ul class="footer-menu">
                                                <li><a href="about-us.html">About Us</a></li>
                                                <li><a href="faq.html">FAQs Page</a></li>
                                                <li><a href="checkout.html">Checkout</a></li>
                                                <li><a href="contact.html">Contact</a></li>
                                                <li><a href="blog.html">Blog</a></li>
                                            </ul>
                                        </div>
                                    </div>

                                    <div class="col-lg-2 col-md-2">
                                        <div class="footer-widget">
                                            <h4 class="widget-title">The Highlights</h4>
                                            <ul class="footer-menu">
                                                <li><a href="#">Apartment</a></li>
                                                <li><a href="#">My Houses</a></li>
                                                <li><a href="#">Restaurant</a></li>
                                                <li><a href="#">Nightlife</a></li>
                                                <li><a href="#">Villas</a></li>
                                            </ul>
                                        </div>
                                    </div>

                                    <div class="col-lg-2 col-md-2">
                                        <div class="footer-widget">
                                            <h4 class="widget-title">My Account</h4>
                                            <ul class="footer-menu">
                                                <li><a href="#">My Profile</a></li>
                                                <li><a href="#">My account</a></li>
                                                <li><a href="#">My Property</a></li>
                                                <li><a href="#">Favorites</a></li>
                                                <li><a href="#">Cart</a></li>
                                            </ul>
                                        </div>
                                    </div>

                                    <div class="col-lg-3 col-md-3">
                                        <div class="footer-widget">
                                            <h4 class="widget-title">Download Apps</h4>
                                            <a href="#" class="other-store-link">
                                                <div class="other-store-app">
                                                    <div class="os-app-icon">
                                                        <i class="lni-playstore theme-cl"></i>
                                                    </div>
                                                    <div class="os-app-caps">
                                                        Google Play
                                                        <span>Get It Now</span>
                                                    </div>
                                                </div>
                                            </a>
                                            <a href="#" class="other-store-link">
                                                <div class="other-store-app">
                                                    <div class="os-app-icon">
                                                        <i class="lni-apple theme-cl"></i>
                                                    </div>
                                                    <div class="os-app-caps">
                                                        App Store
                                                        <span>Now it Available</span>
                                                    </div>
                                                </div>
                                            </a>
                                        </div>
                                    </div>

                                </div>
                            </div>
                        </div>

                        <div class="footer-bottom">
                            <div class="container">
                                <div class="row align-items-center">

                                    <div class="col-lg-6 col-md-6">
                                        <p class="mb-0">© 2021 Resido. Designd By <a href="https://themezhub.com">Themez Hub</a> All Rights Reserved</p>
                                    </div>

                                    <div class="col-lg-6 col-md-6 text-right">
                                        <ul class="footer-bottom-social">
                                            <li><a href="#"><i class="ti-facebook"></i></a></li>
                                            <li><a href="#"><i class="ti-twitter"></i></a></li>
                                            <li><a href="#"><i class="ti-instagram"></i></a></li>
                                            <li><a href="#"><i class="ti-linkedin"></i></a></li>
                                        </ul>
                                    </div>

                                </div>
                            </div>
                        </div>
                    </footer>

                    <div class="modal fade" id="login" tabindex="-1" role="dialog" aria-labelledby="registermodal" aria-hidden="true">
                        <div class="modal-dialog modal-dialog-centered login-pop-form" role="document">
                            <div class="modal-content" id="registermodal">
                                <span class="mod-close" data-bs-dismiss="modal" aria-hidden="true"><i class="ti-close"></i></span>
                                <div class="modal-body">
                                    <h4 class="modal-header-title">Log In</h4>
                                    <div class="login-form">
                                        <form>

                                            <div class="form-group">
                                                <label>User Name</label>
                                                <div class="input-with-icon">
                                                    <input type="text" class="form-control" placeholder="Username" />
                                                    <i class="ti-user"></i>
                                                </div>
                                            </div>

                                            <div class="form-group">
                                                <label>Password</label>
                                                <div class="input-with-icon">
                                                    <input type="password" class="form-control" placeholder="*******" />
                                                    <i class="ti-unlock"></i>
                                                </div>
                                            </div>

                                            <div class="form-group">
                                                <button type="submit" class="btn btn-md full-width btn-theme-light-2 rounded">Login</button>
                                            </div>

                                        </form>
                                    </div>
                                    <div class="modal-divider"><span>Or login via</span></div>
                                    <div class="social-login mb-3">
                                        <ul>
                                            <li><a href="#" class="btn connect-fb"><i class="ti-facebook"></i>Facebook</a></li>
                                            <li><a href="#" class="btn connect-google"><i class="ti-google"></i>Google+</a></li>
                                        </ul>
                                    </div>
                                    <div class="text-center">
                                        <p class="mt-5"><a href="#" class="link">Forgot password?</a></p>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>

                    <div class="modal fade signup" id="signup" tabindex="-1" role="dialog" aria-labelledby="sign-up" aria-hidden="true">
                        <div class="modal-dialog modal-dialog-centered login-pop-form" role="document">
                            <div class="modal-content" id="sign-up">
                                <span class="mod-close" data-bs-dismiss="modal" aria-hidden="true"><i class="ti-close"></i></span>
                                <div class="modal-body">
                                    <h4 class="modal-header-title">Sign Up</h4>
                                    <div class="login-form">
                                        <form>

                                            <div class="row">

                                                <div class="col-lg-6 col-md-6">
                                                    <div class="form-group">
                                                        <div class="input-with-icon">
                                                            <input type="text" class="form-control" placeholder="Full Name" />
                                                            <i class="ti-user"></i>
                                                        </div>
                                                    </div>
                                                </div>

                                                <div class="col-lg-6 col-md-6">
                                                    <div class="form-group">
                                                        <div class="input-with-icon">
                                                            <input type="email" class="form-control" placeholder="Email" />
                                                            <i class="ti-email"></i>
                                                        </div>
                                                    </div>
                                                </div>

                                                <div class="col-lg-6 col-md-6">
                                                    <div class="form-group">
                                                        <div class="input-with-icon">
                                                            <input type="text" class="form-control" placeholder="Username" />
                                                            <i class="ti-user"></i>
                                                        </div>
                                                    </div>
                                                </div>

                                                <div class="col-lg-6 col-md-6">
                                                    <div class="form-group">
                                                        <div class="input-with-icon">
                                                            <input type="password" class="form-control" placeholder="*******" />
                                                            <i class="ti-unlock"></i>
                                                        </div>
                                                    </div>
                                                </div>

                                                <div class="col-lg-6 col-md-6">
                                                    <div class="form-group">
                                                        <div class="input-with-icon">
                                                            <input type="password" class="form-control" placeholder="123 546 5847" />
                                                            <i class="lni-phone-handset"></i>
                                                        </div>
                                                    </div>
                                                </div>

                                                <div class="col-lg-6 col-md-6">
                                                    <div class="form-group">
                                                        <div class="input-with-icon">
                                                            <select class="form-control">
                                                                <option>As a Customer</option>
                                                                <option>As a Agent</option>
                                                                <option>As a Agency</option>
                                                            </select>
                                                            <i class="ti-briefcase"></i>
                                                        </div>
                                                    </div>
                                                </div>

                                            </div>

                                            <div class="form-group">
                                                <button type="submit" class="btn btn-md full-width btn-theme-light-2 rounded">Sign Up</button>
                                            </div>

                                        </form>
                                    </div>
                                    <div class="modal-divider"><span>Or login via</span></div>
                                    <div class="social-login mb-3">
                                        <ul>
                                            <li><a href="#" class="btn connect-fb"><i class="ti-facebook"></i>Facebook</a></li>
                                            <li><a href="#" class="btn connect-google"><i class="ti-google"></i>Google+</a></li>
                                        </ul>
                                    </div>
                                    <div class="text-center">
                                        <p class="mt-5"><i class="ti-user mr-1"></i>Already Have An Account? <a href="#" class="link">Go For LogIn</a></p>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <a id="back2Top" class="top-scroll" title="Back to top" href="#"><i class="ti-arrow-up"></i></a>
                </div>
            </div>
        )
    }
}
