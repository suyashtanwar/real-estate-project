import React, { Component } from 'react'
import face1 from '../../../assets/images/faces/dummy.png'
import { Link, Redirect } from 'react-router-dom'
import axios from 'axios';
import { Tooltip } from 'reactstrap';
import { APIURL, BASEURL } from '../../../components/constants/common';

export default class Sidebar extends Component {
    constructor(props) {
        super(props);
        this.state = {
            sidebarClass: "sidebar-icon-only",
            token: JSON.parse(localStorage.getItem("token")),
            user: JSON.parse(localStorage.getItem("userData")),
            profile_image: "",
            dashboard: false,
            myProfile: false,
            property: false,
            enquiry: false,
            agentreq: false,
            changePass: false,
            // user:false
        }
    }
    componentDidMount() {
        this.getProfileInfo()
        console.log(this.props.data);
        
    }

    getProfileInfo() {
        if (this.state.user) {
            const formData = new FormData();
            // formData.append('token', this.state.token);
            formData.append('id', this.state.user.id);
            var token = this.state.token
            var app_url = APIURL+"agent/edit-profile"
            axios
                .post(app_url, formData, {
                    headers: {
                        'Authorization': `Bearer ${token}`
                    }
                })
                .then((response) => {
                    const info = response.data.data;
                    this.setState({
                        profile_image: info.url_path,
                        name: info.name
                    })
                    this.handleCountryState(this.state.countryId)
                    console.log("sssssssss", this.state.profile_image)
                })
                .catch((error) => {
                    this.setState({
                        // errMsg: error.response.data.errors,
                        Loader: false
                    })
                });
        }
    }

    dashboard = () => { this.setState({ dashboard: !this.state.dashboard }) }
    myProfile = () => { this.setState({ myProfile: !this.state.myProfile }) }
    property = () => { this.setState({ property: !this.state.property }) }
    enquiry = () => { this.setState({ enquiry: !this.state.enquiry }) }
    verified = () => { this.setState({ verified: !this.state.verified }) }
    assigned = () => { this.setState({ assigned: !this.state.assigned }) }
    changePass = () => { this.setState({ changePass: !this.state.changePass }) }
    goback = () => { this.setState({ goback: !this.state.goback }) }

    render() {
        console.log(this.props.activepage)
        const { user, name } = this.state
        if (!this.state.user) {
            // alert("please log in")
            return <Redirect to="/signin" />;
        }
        
        if (this.state.user.user_type !== "Agent") {
            return <Redirect to="/permission" />;
        }
        return (
            <>
                {/* <Helmet>
                    <link rel="stylesheet" href="https://api.imenso.in/css/custom.css" />
                </Helmet> */}
                <nav class="sidebar sidebar-offcanvas" id="sidebar">
                    <ul class="nav">
                        <li class="nav-item nav-profile">
                            <a href="#" class="nav-link">
                                <div class="nav-profile-image">

                                    <img src={this.state.profile_image ? this.state.profile_image : face1} alt="profile" />
                                    <span class="login-status online"></span>
                                </div>
                                <div class="nav-profile-text d-flex flex-column">
                                    <span class="font-weight-bold mb-2">{name}</span>
                                    <span class="text-secondary text-small">Agent</span>
                                </div>
                                <i class="mdi mdi-bookmark-check text-success nav-profile-badge"></i>
                            </a>
                        </li>
                        <li className={this.props.activepage === "dashboard" ? "nav-item active" : "nav-item"}>
                            <Link id="dashboard" class="nav-link" to="/agent" >
                                <span class="menu-title">Dashboard</span>
                                <i class="fas fa-home menu-icon"></i>
                                {document.body.classList.contains(this.state.sidebarClass) ?
                                    <Tooltip placement="right" isOpen={this.state.dashboard} autohide={false} target="dashboard" toggle={this.dashboard}>
                                        DashBoard
                                    </Tooltip>
                                    : ""}
                            </Link>
                        </li>
                        <li className={this.props.activepage === "profile" ? "nav-item active" : "nav-item"}>
                            <Link id="profile" class="nav-link" to="/agent/profile">
                                <span class="menu-title">My Profile</span>
                                <i class="fas fa-user-tie menu-icon"></i>
                                {document.body.classList.contains(this.state.sidebarClass) ?
                                    <Tooltip placement="right" isOpen={this.state.myProfile} autohide={false} target="profile" toggle={this.myProfile}>
                                        My profile
                                    </Tooltip> : ""}

                            </Link>
                        </li>
                        <li className={this.props.activepage === "property" ? "nav-item active" : "nav-item"}>
                            <Link id="Property" class="nav-link" to="/agent/property">
                                <span class="menu-title">Property</span>
                                <i class="far fa-building menu-icon"></i>
                                {document.body.classList.contains(this.state.sidebarClass) ?
                                    <Tooltip placement="right" isOpen={this.state.property} autohide={false} target="Property" toggle={this.property}>
                                        Property
                                    </Tooltip> : ""}
                            </Link>
                        </li>
                        <li className={this.props.activepage === "enquiry" ? "nav-item active" : "nav-item"}>
                            <Link id="Enquiry" class="nav-link" to="/agent/enquiry">
                                <span class="menu-title">Property Enquiry</span>
                                <i class="fas fa-book-reader menu-icon"></i>
                                {document.body.classList.contains(this.state.sidebarClass) ?
                                    <Tooltip placement="right" isOpen={this.state.enquiry} autohide={false} target="Enquiry" toggle={this.enquiry}>
                                        Enquiry
                                    </Tooltip> : ""}
                            </Link>
                        </li>
                        <li className={this.props.activepage === "verified_property" ? "nav-item active" : "nav-item"}>
                            <Link id="verified" class="nav-link" to="/agent/verified/property">
                                <span class="menu-title"> Verified Property</span>
                                <i class="far fa-building menu-icon"></i>
                                {document.body.classList.contains(this.state.sidebarClass) ?
                                    <Tooltip placement="right" isOpen={this.state.verified} autohide={false} target="verified" toggle={this.verified}>
                                        Verified Property
                                    </Tooltip> : ""}
                            </Link>
                        </li>
                        <li className={this.props.activepage === "Assigned_property" ? "nav-item active" : "nav-item"}>
                            <Link id="Assigned" class="nav-link" to="/agent/assigned/property">
                                <span class="menu-title"> Assigned Property</span>
                                <i class="fas fa-users menu-icon"></i>
                                {document.body.classList.contains(this.state.sidebarClass) ?
                                    <Tooltip placement="right" isOpen={this.state.assigned} autohide={false} target="Assigned" toggle={this.assigned}>
                                        Assigned Property
                                    </Tooltip> : ""}
                            </Link>
                        </li>

                        <li className={this.props.activepage === "password" ? "nav-item active" : "nav-item"}>
                            <Link id="Password" class="nav-link" to="/agent/changepassword">
                                <span class="menu-title">Change Password</span>
                                <i class="fas fa-key menu-icon"></i>
                                {document.body.classList.contains(this.state.sidebarClass) ?
                                    <Tooltip placement="right" isOpen={this.state.changePass} autohide={false} target="Password" toggle={this.changePass}>
                                        Change Password
                                    </Tooltip> : ""}
                            </Link>
                        </li>
                    </ul>
                </nav>
            </>
        )
    }
}
