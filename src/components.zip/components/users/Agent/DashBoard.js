import React, { Component } from 'react'
import { Redirect } from 'react-router';
import Navbar from './Navbar';
import Sidebar from './Sidebar';

export default class Index extends Component {
    constructor() {
        super();
        this.state = {
            user: JSON.parse(localStorage.getItem("userData")),
            user_type: localStorage.getItem("user_type"),
            navigate: false
        }
    }

    componentDidMount() {
        console.log(this.state.user_type)
    }

    onLogoutHandler = () => {
        localStorage.removeItem("isLoggedIn");
        localStorage.removeItem("userData");
        localStorage.clear();
        this.setState({
            navigate: true,
        });
    };


    render() {
        if (!this.state.user) {
            return <Redirect to="/signin" />;
        }
        if(this.state.user.user_type !== "Agent"){
            return <Redirect to="/permission" />;
        }
        return (
            <>
                <div class="container-scroller resido-admin">
                    <Navbar />
                    <div class="container-fluid page-body-wrapper">
                        <Sidebar activepage="dashboard" />
                        <div class="main-panel">
                            <div class="content-wrapper">
                                <div class="row">
                                    <div class="col-12 grid-margin stretch-card">
                                        <div class="card">
                                            <div class="card-body">
                                                <h4 class="card-title">Coming Soon</h4>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <footer class="footer">
                                <div class="container-fluid clearfix">
                                    <span class="text-muted d-block text-center text-sm-left d-sm-inline-block">Copyright © website.com 2021</span>
                                </div>
                            </footer>
                        </div>
                    </div>
                </div>
            </>
        )
    }
}
