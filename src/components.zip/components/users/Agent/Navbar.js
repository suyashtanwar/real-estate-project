import React, { Component } from 'react'
import logo from '../../../assets/img/logo.png'
import logoMini from '../../../assets/img/logo-mini.png'
import { Redirect, Link } from 'react-router-dom';
import axios from "axios";
import Sidebar from './Sidebar'
import { APIURL, BASEURL } from '../../../components/constants/common';

export default class Navbar extends Component {
    constructor() {
        super();
        this.state = {
            token: JSON.parse(localStorage.getItem("token")),
            user: JSON.parse(localStorage.getItem("userData")),
            user_type: localStorage.getItem("user_type"),
            navigate: false,
            profile_image: "",
            openSidebar: false
        }
    }

    componentDidMount() {
        this.setState({
            openSidebar: false
        })
        this.getProfileInfo()
        console.log(this.props.data)
        
    }
    goToHome(){
        window.location.href="/";
    }

    getProfileInfo() {
        if (this.state.user) {
            const formData = new FormData();
            // formData.append('token', this.state.token);
            formData.append('id', this.state.user.id);
            var token = this.state.token
            var app_url = APIURL+"agent/edit-profile"
            axios
                .post(app_url, formData, {
                    headers: {
                        'Authorization': `Bearer ${token}`
                    }
                })
                .then((response) => {
                    const info = response.data.data;
                    this.setState({
                        profile_image: response.data.data.url_path,
                        name: response.data.data.name
                    })
                    console.log("bjsbvjx", this.state.profile_image)
                })
                .catch((error) => {
                    this.setState({
                        // errMsg: error.response.data.errors,
                        Loader: false
                    })
                });
        }
    }

    onLogoutHandler = () => {
        localStorage.removeItem("isLoggedIn");
        localStorage.removeItem("userData");
        localStorage.clear();
        this.setState({
            navigate: true,
        });
    };

    onHover = () =>
        this.setState({
            showIcons: true
        });
    onNotHover = () =>
        this.setState({
            showIcons: false
        });

    Sidebar = (event) => {
        this.setState({
            openSidebar: !this.state.openSidebar
        })
        if (this.state.openSidebar) {
            document.body.classList.remove('sidebar-icon-only');
        }
        if (!this.state.openSidebar) {
            document.body.classList.add('sidebar-icon-only');
        }
    }


    render() {
        if (!this.state.user) {
            alert("please log in")
            return <Redirect to="/signin" />;
        }
        
        const { openSidebar, closeSidebar } = this.state
        console.log(this.props.data)
        const { user, name } = this.state
        if (!this.state.user_type === "agent") {
            return <Redirect to="/" push={true} />;
        }

        if (!this.state.user) {
            return <Redirect to="/" push={true} />;
        }

        if (this.state.navigate) {
            return <Redirect to="/" push={true} />;
        }
        return (
            <>
                <div className="d-none" ><Sidebar openSidebar={this.state.openSidebar} /></div>
                <nav class="navbar default-layout-navbar col-lg-12 col-12 p-0 fixed-top d-flex flex-row">
                    <div class="text-center navbar-brand-wrapper d-flex align-items-center justify-content-center">
                        <button class="navbar-brand brand-logo" onClick={() =>this.goToHome()}><img src={logo} alt="logo" /></button>
                        <Link class="ml-4 navbar-brand brand-logo-mini" to="/"><img src={logoMini} alt="logo" /></Link>
                    </div>
                    <div class="navbar-menu-wrapper d-flex align-items-stretch">
                        <div className="mt-3">
                        {openSidebar ? 
                        <span class=" navbar-toggler navbar-toggler align-self-center" type="button" data-toggle="minimize">
                                <span onClick={() =>this.Sidebar()} class="fas fa-bars"></span>
                            </span> 
                            : 
                            <span class=" navbar-toggler navbar-toggler align-self-center" type="button" data-toggle="minimize">
                            <span onClick={() =>this.Sidebar()} class="fas fa-bars"></span>
                        </span>
                            } 
                        </div>



                        {/* <div class="search-field d-none d-md-block">
                                <form class="d-flex align-items-center h-100" action="#">
                                    <div class="input-group">
                                        <div class="input-group-prepend bg-transparent">
                                            <i class="input-group-text border-0 mdi mdi-magnify"></i>
                                        </div>
                                        <input type="text" class="form-control bg-transparent border-0" placeholder="Search projects" />
                                    </div>
                                </form>
                            </div> */}
                        <ul class="navbar-nav navbar-nav-right">
                            <li class="nav-item nav-profile dropdown">
                                {/* <a class="nav-link dropdown-toggle" id="profileDropdown" href="#" data-toggle="dropdown" aria-expanded="false">

                                    <Link class="nav-profile-img" to="/agent/profile">
                                        <img src={this.state.profile_image ? this.state.profile_image : face1} alt="profile" />
                                    </Link>
                                    <div class="nav-profile-text" >
                                        <p class="mb-1 text-black">{name}</p>
                                    </div>
                                </a> */}
                                {/* <div class="ml-5 dropdown-menu navbar-dropdown" aria-labelledby="profileDropdown">
                                   <div class="dropdown-divider"></div>
                                    <a onClick={() => this.onLogoutHandler()} class="dropdown-item" href="#">
                                        <i  class="mdi mdi-logout mr-2 text-primary"></i> Signout </a>
                                </div> */}
                            </li>
                            {/* <li class="nav-item d-none d-lg-block full-screen-link">
                                    <a class="nav-link">
                                        <i class="mdi mdi-fullscreen" id="fullscreen-button"></i>
                                    </a>
                                </li> */}

                            <li class="nav-item nav-logout d-none d-lg-block mr-3">
                                <a class="nav-link" href="#" onClick={() => this.onLogoutHandler()} style={{ width: "50px" }}>
                                    <strong>Logout</strong>
                                    <i data-bs-toggle="tooltip" data-bs-placement="bottom" title="Logout" onClick={() => this.onLogoutHandler()} class="mdi mdi-power ml-2">  </i>
                                </a>
                            </li>
                            {/* <li class="nav-item nav-settings d-none d-lg-block">
                                    <a class="nav-link" href="#">
                                        <i class="mdi mdi-format-line-spacing"></i>
                                    </a>
                                </li> */}
                        </ul>
                        <button class="navbar-toggler navbar-toggler-right d-lg-none align-self-center" type="button" data-toggle="offcanvas">
                            <span class="mdi mdi-menu"></span>
                        </button>
                    </div>
                </nav>
            </>
        )
    }
}
