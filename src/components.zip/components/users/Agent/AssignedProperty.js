import React, { Component } from 'react'
import Sidebar from './Sidebar'
import Navbar from './Navbar'
import { Button } from 'reactstrap'
import axios from "axios";
import { Redirect } from 'react-router-dom'
import { APIURL } from '../../constants/common';
import { Modal, ModalBody, ModalHeader, ModalFooter, Input, Spinner } from 'reactstrap'
import Pagination from "react-js-pagination";
import Select from 'react-select'
import dateFormat, { masks } from "dateformat";

const colourStyles = {

    option: (styles, { data, isDisabled, isFocused, isSelected }) => {
        return {
            ...styles,
            backgroundColor: isFocused ? "#B8BCBD" : null,
            color: "grey",
        };
    },
};
export default class Property extends Component {
    constructor() {
        super();
        this.state = {
            token: JSON.parse(localStorage.getItem("token")),
            user: JSON.parse(localStorage.getItem("userData")),
            propertyRequest: [],
            statusArray: [{ 'value': "", "label": "Status" }, { 'value': "under_review", "label": "Under Review" }, { 'value': "pending", "label": "Pending" }, { 'value': "accept", "label": "Accepted" }, { 'value': "unverify", "label": "Not Verified" }],
            statusDefault: [{ 'value': "", "label": "Status" }],
            CommetModal: false,
            isLoading: false,
            rejectComment: "",
            errMsg: "",
            scsMsg: "",
            Loader: false,
            activePage: 1,
            limit: 0,
            totalItemsCount: 0,
            search: "",
            status: [],
            sort: false,
            sortby: "DESC",
            columnName: ""
        }
    }

    componentDidMount() {
        this.getAgentRequests()
    }
    SortBy(e) {
        this.setState({
            sort: !this.state.sort
        }, () => {
            if (this.state.sort) {
                this.setState({
                    sortby: "ASC",
                    columnName: e
                }, () => {
                    this.getAgentRequests()
                })

            }
            if (!this.state.sort) {
                this.setState({
                    sortby: "DESC",
                    columnName: e
                }, () => {
                    this.getAgentRequests()
                })
            }
        })
    }

    handleSearch(e) {
        this.setState(
            { search: e.target.value, activePage: 1 }
            , () => { this.getAgentRequests() });
    }

    handleStatus(e) {
        this.setState(
            {
                status: e.value,
                statusDefault: [{ value: e.value, label: e.label }]
            }
            , () => { this.getAgentRequests() });
    }

    handlePageChange(pageNumber) {
        console.log(`active page is ${pageNumber}`);
        this.setState(
            { activePage: pageNumber }
            , () => {
                this.getAgentRequests()
            }
        );
    }

    getAgentRequests() {
        const token = this.state.token
        const formData = new FormData();
        formData.append('page', this.state.activePage);
        formData.append('search', this.state.search);
        formData.append('statusfilter', this.state.status);
        formData.append('sortby', this.state.sortby);
        formData.append('limit', this.state.limit);
        formData.append('sorttype', this.state.columnName);
        axios
            .post(APIURL + "agent/get-assign-properties", formData, {
                headers: {
                    'Authorization': `Bearer ${token}`
                }
            })
            .then((response) => {
                console.log("agent/get-assign-properties", response.data.data.data)
                if (response.data.data.data && response.data.data.data.length > 0) {
                    this.setState({
                        propertyRequest: response.data.data.data,
                        activePage: response.data.data.current_page,
                        totalItemsCount: response.data.data.total,
                        limit: response.data.data.per_page
                    });
                }
            });
    }

    CommetModal(e) {
        this.setState({
            CommetModal: !this.state.CommetModal,
        })
    }

    ModalClose() {
        this.setState({
            CommetModal: false
        })
    }
    rejectComment(e) {
        this.setState({
            rejectComment: e
        })
    }
    ViewDetailsPreview(e) {
        this.setState({
            ViewPropertyId: e.id,
            goToPreview: true
        })
    }

    SubmitRequest = (e, status) => {
        this.setState({ isLoading: true })
        var token = this.state.token

        const formData = new FormData();
        formData.append('property_id', e.id);
        formData.append('status', status);
        formData.append('comment', this.state.rejectComment)

        this.setState({ Loader: true, CommetModal: false });
        axios
            .post(APIURL + "agent/update-property-assign-request-status", formData, {
                headers: {
                    'Authorization': `Bearer ${token}`
                }
            })
            .then((response) => {
                this.setState({
                    Loader: false,
                    scsMsg: response.data.message,
                    updateStatus: response.data.data.status
                });
                this.getAgentRequests()

            })
            .catch((error) => {
                this.setState({
                    errMsg: error.response.data.error,
                    Loader: false,
                    CommetModal: false,
                    isLoading: false
                })
            });
        this.getAgentRequests()
    };


    render() {
        if (!this.state.user) {
            return <Redirect to="/signin" />;
        }
        if (this.state.goToPreview) {
            return <Redirect to={"/agent/property/details/" + this.state.ViewPropertyId} push={true} />;
        }
        return (
            <div>
                {this.state.Loader ? <div className="loader"> <Spinner type="grow" color="dark" style={{ width: '3rem', height: '3rem' }} /> </div> : ""}

                <div class="container-scroller resido-admin">
                    <Navbar />
                    <div class="container-fluid page-body-wrapper">
                        <Sidebar activepage="Assigned_property" />
                        <div class="main-panel">
                            <div class="content-wrapper">
                                <div className="mb-4 d-flex justify-content-between">
                                    <h4 className="text-uppercase">Assigned Property</h4>
                                </div>
                                {this.state.scsMsg || this.state.errMsg ?
                                    <div className={this.state.scsMsg ? "alert alert-success mb-4" : "alert alert-danger mb-4"} role="alert">
                                        {this.state.scsMsg} {this.state.errMsg.message}
                                    </div>
                                    : ""}
                               
                                 <div className="row">
                                 <div className="col-3">
                                        <Input type="text" onChange={(e) => this.handleSearch(e)} placeholder="Search" />
                                    </div>
                                    <div className="col-3 ml-auto">
                                    <Select
                                            aria-label=".form-select-lg example"
                                            required=""
                                            placeholder="Select Status"
                                            className="form-select-control"
                                            options={this.state.statusArray}
                                            value={this.state.statusDefault}
                                            styles={colourStyles}
                                            onChange={(e) => this.handleStatus(e)}
                                        />
                                    </div>
                                </div>
                                <div class="row mt-3">
                                    <div class="col-12 grid-margin">
                                        <div class="card">
                                            <div class="card-body">
                                                <div class="table-responsive">
                                                    <table class="table ">
                                                        <thead>
                                                            <tr>
                                                                <th className="sort-by" style={{ cursor: "pointer" }} onClick={(e) => this.SortBy("name")}>Property Name</th>
                                                                <th className="sort-by"  style={{ cursor: "pointer" }} onClick={(e) => this.SortBy("seller_name")}> Seller Name</th>
                                                                <th className="sort-by" style={{ cursor: "pointer" }} onClick={(e) => this.SortBy("created_at")}>Created Date</th>
                                                                <th> Status</th>
                                                                <th className="text-center"> Action </th>
                                                            </tr>
                                                        </thead>
                                                        <tbody>
                                                            {this.state.propertyRequest.length > 0 || [] ? this.state.propertyRequest.map((item, idx) => (
                                                                <React.Fragment>
                                                                    <tr style={{ fontWeight: "700" }}>
                                                                        <td >{item.name}</td>
                                                                        <td >{item.seller_detail.name}</td>
                                                                        <td > {dateFormat(item.created_at,'dd-mm-yyyy')}</td>
                                                                        <td>
                                                                            {
                                                                                item.propertyAssignedStatus === "accept" && item.propertyVerifiedStatus === "verify" ?
                                                                                    <label className="badge badge-success">Verified</label>
                                                                                    :
                                                                                    item.propertyAssignedStatus === "accept" && item.propertyVerifiedStatus === "unverify" ?
                                                                                        <label className="badge badge-warning">Not verified</label>
                                                                                        :
                                                                                        item.propertyAssignedStatus === "accept"
                                                                                         ?
                                                                                            <label className="badge badge-dark">Accepted</label>
                                                                                            :
                                                                                            item.propertyAssigned ?
                                                                                                <label className="badge badge-dark">Under Review</label> :
                                                                                                <div>
                                                                                                    <label className="badge badge-danger">Pending</label>
                                                                                                </div>
                                                                            }
                                                                        </td>
                                                                        <td className="text-center">
                                                                            <div>
                                                                                <Button size="sm" type="button" className="badge badge-info btn-rounded px-3 btn-sm mr-1 " outline onClick={(e) => this.ViewDetailsPreview(item)} >View</Button>

                                                                            </div>
                                                                        </td>
                                                                    </tr>
                                                                    <Modal size="md" isOpen={this.state.CommetModal} toggle={() => this.ModalClose()}>
                                                                        <ModalHeader className="header-less ml-3" toggle={() => this.ModalClose()}>Property Detail</ModalHeader>
                                                                        <ModalBody className="border-0">
                                                                            <div className="row">
                                                                                <div className="col-lg-12 col-md-6">
                                                                                    <div className="form-group">
                                                                                        <label> Comment <strong className="text-danger" ></strong></label>
                                                                                        <div className="input-with-icon">
                                                                                            <textarea
                                                                                                className="form-control"
                                                                                                style={{ height: "100px", backgroundColor: "#9999" }}
                                                                                                required=""
                                                                                                type="textarea"
                                                                                                name="comment"
                                                                                                placeholder="write here"
                                                                                                value={this.state.rejectComment}
                                                                                                onChange={(e) => this.rejectComment(e.target.value)}
                                                                                            />
                                                                                        </div>
                                                                                    </div>
                                                                                </div>
                                                                            </div>
                                                                        </ModalBody>
                                                                        <ModalFooter>
                                                                            <div className="d-flex justify-content-between w-100">
                                                                                <Button color="primary" className="btn btn-primary" onClick={(e) => this.SubmitRequest(item, "reject")}> <i className="fas fa-save mr-1"> </i>Submit</Button>
                                                                                <Button className="btn btn-danger" onClick={() => this.ModalClose()}> <i className="fas fa-window-close mr-1"></i>Cancel </Button>
                                                                            </div>
                                                                        </ModalFooter>
                                                                    </Modal>
                                                                </React.Fragment>
                                                            )) :
                                                                <tr>
                                                                    <td colSpan="3" className="text-center">
                                                                        No Request Available
                                                                    </td>
                                                                </tr>
                                                            }
                                                        </tbody>
                                                    </table>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div className="d-flex justify-content-center">
                                    {this.state.totalItemsCount > 0 &&
                                        <div className="pagination-rounded">
                                            <Pagination
                                                activePage={this.state.activePage}
                                                itemsCountPerPage={this.state.limit}
                                                totalItemsCount={this.state.totalItemsCount}
                                                pageRangeDisplayed={5}
                                                onChange={this.handlePageChange.bind(this)}
                                            />
                                        </div>
                                    }
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        )
    }
}
