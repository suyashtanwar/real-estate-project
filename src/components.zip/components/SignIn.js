import React, { Component } from 'react'
// import '../frontend_css/'
import logo from '../assets/img/logo.png'
import { Link } from 'react-router-dom'
import axios from "axios";
import { Spinner ,    Button } from 'reactstrap';
import { Redirect } from 'react-router-dom'
import { APIURL, BASEURL } from '../components/constants/common';
export default class SignIn extends Component {
    constructor(props) {
        super(props);
        this.state = {
            username: "",
            password: "",
            errMsgEmail: "",
            errMsgPwd: "",
            msg: "",
            isLoading: false,
            redirect: false,
            errMsg: [],
            scsMsg: "",
            showPassword: false,
            modal: false,
            fullScrLoader: true,
            user: JSON.parse(localStorage.getItem("userData")),
            accountVerified:true,
            scsMsgResend:"",
            ActiveMsg:"",
            stylePath:true
        }
        this.handleSubmit = this.handleSubmit.bind(this);
    }

    onChangehandler = (e) => {
        console.log(e)
        let name = e.target.name;
        let value = e.target.value;
        let data = {};
        data[name] = value;
        this.setState(data);
        console.log(data)
    };

    handleUserName(e) {
        console.log(e)
        this.setState({
            userName: e
        })
        console.log(this.state.userName)
    }

    handlePassword(e) {
        console.log(e)
        this.setState({
            password: e
        })
        console.log(this.state.password)
    }

    handleSubmit(e) {
        e.preventDefault();
        this.setState({ isLoading: true });
        axios
            .post(APIURL + "login", {
                email: this.state.email,
                password: this.state.password,
            })
            .then((response) => {
                this.setState({
                    isLoading: false,
                   
                })
                localStorage.setItem("isLoggedIn", true);
                localStorage.setItem("userData", JSON.stringify(response.data.user));
                localStorage.setItem("token", JSON.stringify(response.data.token));
                this.setState({
                    redirect: true,
                });
            })
            .catch((error) => {
                this.setState({
                    isLoading: false,
                    accountVerified:error.response.data.accountVerified,
                    errMsg: error.response.data.error,
                })
                setTimeout(() => this.setState({ errMsg: "" }), 4000);
            });
    }

    showPassword() {
        this.setState({
            showPassword: !this.state.showPassword
        })
    }


    resendActivationMail = () => {
        axios
            .post(APIURL + "resend/email", {
                email: this.state.email,
            })
            .then((response) => {
                this.setState({
                    scsMsgResend:response.data.message,
                    errMsg:""
                })
            });
    }


    ActivationMsg = () => {
        const params = this.props.match.params
        // console.log(params.id)
        if(params.token){
            axios
            .get(APIURL + "email/verify/"+ params.token)
            .then((response) => {
              
                this.setState({
                    ActivationMsg:response.data.message
                })
                setTimeout(() => this.setState({ ActivationMsg: false }), 4000);
               
            })
            .catch((error) => {
                this.setState({
                    errMsg: error.response.data.error,
                })
               
            });
        }
    }

    componentDidMount() {
        this.ActivationMsg()
        setTimeout(() => this.setState({ fullScrLoader: false }), 500);
       
    }
   

    render() {
        console.log(this.props)
        const { user } = this.state;
        if (this.state.redirect) {
            return <Redirect to="/checkuser" />;
        }
        return (
            <div className="resido-front">
                {this.state.fullScrLoader ? <div className="loader"> <Spinner type="grow" color="dark" style={{ width: '3rem', height: '3rem' }} /> </div> : ""}
                <div id="main-wrapper">
                    <div className="header header-light head-shadow">
                        <div className="container">
                            <nav id="navigation" className="navigation navigation-landscape">
                                <div className="nav-header">
                                    <a className="nav-brand" href="#">
                                        <img src={logo} className="logo" alt="" />
                                    </a>
                                    <div className="nav-toggle"></div>
                                </div>
                                <div className="nav-menus-wrapper" style={{ transitionProperty: "none" }}>
                                    <ul className="nav-menu">
                                        <li className=""><Link to="/">Home<span className="submenu-indicator"></span></Link></li>
                                        <li><Link to="/Listing">Listings<span className="submenu-indicator"></span></Link></li>
                                        <li><Link to="/features">Features<span className="submenu-indicator"></span></Link></li>
                                    </ul>

                                    <ul className="nav-menu nav-menu-social align-to-right">
                                        <li>
                                            <Link to="/signup" className="text-success">
                                                <i className="fas fa-user-circle mr-2"></i>Sign Up</Link>
                                        </li>
                                       
                                    </ul>
                                </div>
                            </nav>
                        </div>
                    </div>

                    <div className="modal-dialog modal-dialog-centered login-pop-form" role="document">
                        <div className="modal-content" id="registermodal">
                            <div class="card login-pop-form">
                                <div class="card-body">
                                    <h4 className="modal-header-title">Log In</h4>
                                    {this.state.errMsg.message ? <div class="alert alert-danger" role="alert">
                                        {this.state.errMsg.message}<br /> 
                                        {this.state.accountVerified ? "" : 
                                    <a className="text-secondary font-weight-bold " onClick={this.resendActivationMail} href="javascript:;">Resend Verification Link</a>
                                    }
                                    </div> : ""}

                                     {/* success msg */}
                                     {this.state.scsMsgResend ? 
                                       <div class="alert alert-success" role="alert">
                                        {this.state.scsMsgResend}
                                       </div> : ""
                                       } 

                                       {/* activtion msg */}
                                       {this.state.ActivationMsg ? 
                                       <div class="alert alert-success" role="alert">
                                        {this.state.ActivationMsg}
                                       </div> : ""
                                       } 
                                    {/* <span className="text-danger"></span> */}
                                    <div className="login-form">
                                        <form onSubmit={(e) => this.handleSubmit(e)}>
                                            <div className="form-group">
                                                <label>Email Address <strong className="text-danger" >*</strong></label>
                                                <div className="input-with-icon">
                                                    <input
                                                        autoFocus={true}
                                                        className="form-control"
                                                        required=""
                                                        type="text"
                                                        name="email"
                                                        id="email"
                                                        placeholder="Email Address "
                                                        value={this.state.email}
                                                        onChange={this.onChangehandler}
                                                    />
                                                    <i className="ti-user"></i>
                                                </div>
                                                <span className="text-danger">{this.state.errMsg.email}</span>

                                            </div>

                                            <div className="form-group">
                                                <label>Password <strong className="text-danger" >*</strong></label>
                                                <div className="position-relative">
                                                    <div className="input-with-icon">
                                                        <input
                                                            className="form-control"
                                                            type={this.state.showPassword ? "text" : "password"}
                                                            name="password"
                                                            id="password"
                                                            placeholder="Password"
                                                            value={this.state.password}
                                                            onChange={this.onChangehandler}
                                                        />
                                                        <i className="ti-unlock"></i>
                                                    </div>
                                                    {this.state.showPassword ?
                                                        <span href="" className="fa-eye-pass"> <i onClick={() => this.showPassword()} className="fas fa-eye-slash"></i> </span>
                                                        :
                                                        <span href="" className="fa-eye-pass"> <i onClick={() => this.showPassword()} className="fas fa-eye"></i> </span>
                                                    }
                                                </div>
                                                {/* {this.state.showPassword ?
                                                    <i onClick={() => this.showPassword()} class="fas fa-eye-slash"></i>
                                                    :
                                                    <i onClick={() => this.showPassword()} class="fas fa-eye"></i>
                                                } */}
                                                <span className="text-danger">{this.state.errMsg.password}</span>

                                            </div>
                                            <div className="form-group">
                                                {/* <input
                                                type="submit" value="Login"
                                                    className="btn btn-md full-width btn-theme-light-2 rounded"
                                                    // onClick={() => this.handleSignIn()}
                                               /> */}
                                                <Button
                                                    type="submit"
                                                    className="btn btn-md full-width btn-theme-light-2 rounded"
                                                >
                                                    Login
                                                    {this.state.isLoading ? (
                                                        <span
                                                            className="spinner-border spinner-border-sm ml-2"
                                                            role="status"
                                                            aria-hidden="true"
                                                        ></span>
                                                    ) : (
                                                        <span></span>
                                                    )}
                                                </Button>
                                            </div>
                                        </form>
                                    </div>
                                    <div className="text-center">
                                        <p className="mt-2"><Link to="/forgot/password" className="link">Forgot password?</Link></p>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        )
    }
}
