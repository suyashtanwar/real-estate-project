import React, { Component } from 'react'
import logo from '../../assets/img/logo.png'
import { Link } from 'react-router-dom'

export default class Navbar extends Component {
	constructor() {
		super();
		this.state = {
			user: JSON.parse(localStorage.getItem("userData")),
			user_type: localStorage.getItem("user_type"),
			navigate: false
		}
	}
	goToProfile(){
		if(this.state.user) {
			if(this.state.user.user_type=="Agent")
			{
				window.location.href="/agent";
			}
			else if(this.state.user.user_type=="Seller")
			{
	            window.location.href="/seller";
			}
			else if(this.state.user.user_type=="Admin")
			{
	            window.location.href="/Admin";
			}
			else
			{
				  window.location.href="/Buyer";
				
			}
		}
    }

	render() {
		const { user_type } = this.state
		return (
			<div>
				<div className="header header-transparent change-logo">
					<div className="container">
						<nav id="navigation" className="navigation navigation-landscape">
							<div className="nav-header">
								<a className="nav-brand static-logo" href="#"><img src={logo} className="logo" alt="" /></a>
								<a className="nav-brand fixed-logo" href="#"><img src={logo} className="logo" alt="" /></a>
								<div className="nav-toggle"></div>
							</div>
							<div className="nav-menus-wrapper" style={{ transitionProperty: "none" }}>
								<ul className="nav-menu">
									<li className=" "><Link to="/">Home<span className="submenu-indicator"></span></Link></li>
									<li><Link to="/Listing">Listings<span className="submenu-indicator"></span></Link></li>
									<li><Link to="/features">Features<span className="submenu-indicator"></span></Link></li>
									<li>
										{this.state.user ?
											""
											:
											<Link to="/signup" ><img src="assets/img/user.svg" width="12" alt="" className="mr-2" />Sign Up</Link>
										}

									</li>
								</ul>
								<ul className="nav-menu nav-menu-social align-to-right">
									
									<li className="add-listing light">
										{this.state.user ?
											<button classNa onClick={() =>this.goToProfile()} ><img src="assets/img/user.svg" width="12" alt="" className="mr-2" />Profile</button>
											:
											<Link to="/signin" ><img src="assets/img/user.svg" width="12" alt="" className="mr-2" />Sign In</Link>
										}</li>
								</ul>
							</div>
						</nav>
					</div>
				</div>
			</div>
		)
	}
}
