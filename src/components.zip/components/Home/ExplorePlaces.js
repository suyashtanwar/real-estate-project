import React, { Component } from 'react'
import logo from '../../assets/img/logo.png'
import { Link } from 'react-router-dom'
import axios from 'axios';
import { APIURL } from '../constants/common';

export default class ExplorePlaces extends Component {
	constructor() {
		super();

		this.state = {
			PropertyList: []
		}
	}

	componentDidMount() {
		this.getPropertyList()
	}

	getPropertyList() {
		axios
			.get(APIURL + "get-latest-properties")
			.then((response) => {
				console.log("get-latest-properties", response.data.data)
				this.setState({
					PropertyList: response.data.data
				})
			})
			.catch(error => {
				// alert(error)
			})
	}
	render() {
		return (
			<div>
				<section>
					<div className="container">

						<div className="row justify-content-center">
							<div className="col-lg-7 col-md-10 text-center">
								<div className="sec-heading center">
									<h2>Latest Properties</h2>
									{/* <p>At vero eos et accusamus et iusto odio dignissimos ducimus qui blanditiis praesentium voluptatum deleniti atque corrupti quos dolores</p> */}
								</div>
							</div>
						</div>
						<div className="row">
							{this.state.PropertyList.length > 0 ? this.state.PropertyList.map((item, idx) => (
								<div key={idx} className="col-lg-4 col-md-6 col-sm-12">
										{	item.property_detail.map((sItem, idx) => (
								
									<div className="property-listing property-2">
										<div className="listing-img-wrapper">
											<div className="list-img-slide">
												<div className="click">
													<div><a href="single-property-1.html"><img src="https://via.placeholder.com/1200x800" className="img-fluid mx-auto" alt="" /></a></div>
													<div><a href="single-property-1.html"><img src="https://via.placeholder.com/1200x800" className="img-fluid mx-auto" alt="" /></a></div>
													<div><a href="single-property-1.html"><img src="https://via.placeholder.com/1200x800" className="img-fluid mx-auto" alt="" /></a></div>
												</div>
											</div>
										</div>
										<div className="listing-detail-wrapper">
											<div className="listing-short-detail-wrap">
												<div className="listing-short-detail">
													<span className="property-type">For Rent</span>
													<h4 className="listing-name verified"><a href="single-property-1.html" className="prt-link-detail">{item.name}</a></h4>
												</div>
												<div className="listing-short-detail-flex">
													<h6 className="listing-card-info-price">${sItem.listing_price}</h6>
												</div>
											</div>
										</div>
									
										<div className="price-features-wrapper">
											<div className="list-fx-features">
												<div className="listing-card-info-icon">
													<div className="inc-fleat-icon"><img src="assets/img/bed.svg" width="13" alt="" /></div>{sItem.number_of_bedrooms ? sItem.number_of_bedrooms : "NA"} Beds
												</div>
												<div className="listing-card-info-icon">
													<div className="inc-fleat-icon"><img src="assets/img/bathtub.svg" width="13" alt="" /></div>{sItem.number_of_bathrooms ? sItem.number_of_bathrooms : "NA"}Bath
												</div>
												<div className="listing-card-info-icon">
													<div className="inc-fleat-icon"><img src="assets/img/move.svg" width="13" alt="" /></div>{sItem.lot_size ? sItem.lot_size : "NA"} sqft
												</div>
											</div>
										</div>

										<div className="listing-detail-footer">
											<div className="footer-first">
												<div className="foot-location"><img src="assets/img/pin.svg" width="18" alt="" />
												{sItem.apt_number === "null"? "NA":sItem.apt_number}, 
												{sItem.street_name === "null"? "NA":sItem.street_name} ,
												 {sItem.city === "null"? "NA":sItem.city}</div>
											</div>
											<div className="footer-flex">
												<Link to={"/viewproperty/details/" + item.id} className="prt-view">View</Link>
											</div>
										</div>
									</div>
									))}
								</div>

							)) :
								<table>
									<tbody>
									<tr>
									<td colSpan="3" className="text-center">
										No Property Available
									</td>
								</tr>
									</tbody>
									</table>
							}
						</div>
						<div className="row">
							<div className="col-lg-12 col-md-12 col-sm-12 text-center">
								<a href="listings-list-with-sidebar.html" className="btn btn-theme-light-2 rounded">Browse More Properties</a>
							</div>
						</div>

					</div>
				</section>
			</div>
		)
	}
}
