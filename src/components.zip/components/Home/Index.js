import React, { Component } from 'react'
import logo from '../../assets/img/logo.png'
import Navbar from './Navbar'
import Header from './Header'
import ExplorePlaces from './ExplorePlaces'
import HowItWorks from './HowItWorks'
import SearchPlace from './SearchPlace'
import News from './News'
import Footer from './Footer'

export default class Home extends Component {
	constructor(){
		super();
		this.state = {
			stylePath:true
		}
	}

	componentDidMount(){
          
	}

	render() {
		console.log(this.props)
		return (
		<div className="resido-front">	
			<div id="main-wrapper" className="blue-skin">

				{/* Navbar cmp */}
				<Navbar />

				{/* header cmp */}

				<div className="clearfix"></div>
				<Header />

				{/* explore places cmp */}
				<ExplorePlaces />

				{/* FindByPlaces */}
				{/* <FindByPlaces /> */}

				{/* how it Works */}
				<HowItWorks />

				<div className="clearfix"></div>
				{/* SearchPlace cmp */}
				<SearchPlace />

				{/* news cmp */}
				<News />

				{/* footer cmp */}
				<Footer />

				
			</div>

		</div>	
		)
	}
}
