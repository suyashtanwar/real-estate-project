import React, { Component } from 'react'
import logo from '../../assets/img/logo.png'

export default class Header extends Component {
    render() {
        return (
            <>
                <div className="image-cover hero-banner" style={{backgroundImage: `url(${"https://via.placeholder.com/1920x900"})`}}  data-overlay="6">
				<div className="container">

					<h1 className="big-header-capt mb-0">Find Your Property</h1>
					<p className="text-center mb-5">From as low as $10 per day with limited time offer</p>
					
					<div className="full-search-2 eclip-search italian-search hero-search-radius shadow">
						<div className="hero-search-content">
							
							<div className="row">
							
								<div className="col-lg-4 col-md-4 col-sm-12 b-r">
									<div className="form-group">
										<div className="input-with-icon">
											<input type="text" className="form-control" placeholder="Neighborhood" />
											<i className="ti-search"></i>
										</div>
									</div>
								</div>
	
								
								<div className="col-lg-3 col-md-3 col-sm-12">
									<div className="form-group">
										<div className="input-with-icon">
											<select id="ptypes" className="form-control">
												<option value="">&nbsp;</option>
												<option value="1">Any Type</option>
												<option value="2">Apartment</option>
												<option value="3">Villas</option>
												<option value="4">Commercial</option>
												<option value="5">Offices</option>
												<option value="6">Garage</option>
											</select>
											<i className="ti-briefcase"></i>
										</div>
									</div>
								</div>

								
								<div className="col-lg-3 col-md-3 col-sm-12">
									<div className="form-group">
										<div className="input-with-icon b-l">
											<select id="location" className="form-control">
												<option value="">&nbsp;</option>
												<option value="1">New York City</option>
												<option value="2">Chicago, Illinois</option>
												<option value="3">Las Vegas</option>
												<option value="4">New Orleans</option>
												<option value="5">San Francisco</option>
												<option value="6">Washington</option>
											</select>
											<i className="ti-location-pin"></i>
										</div>
									</div>
								</div>
								
								<div className="col-lg-2 col-md-2 col-sm-12">
									<div className="form-group">
										<a href="#" className="btn search-btn">Search</a>
									</div>
								</div>
								
							</div>
							
						</div>
					</div>
						
				</div>
			</div>
            </>
        )
    }
}
